#pragma once
#include "Prediction.h"
#include "CenterPrior.h"
#include "BoxInfo.h"
#include "ObjectRect.h"
#include <msclr/marshal.h>
#include <msclr/marshal_cppstd.h>

using namespace System;
using namespace System::Drawing;
using namespace System::Runtime::InteropServices;
using namespace System::Collections::Generic;
using namespace System::Collections;

/*#pragma comment(lib, "../x64/Debug/DefectDetectionCpp.lib")
#pragma comment(lib, "../x64/Debug/opencv_world455d.lib")*/

#pragma comment(lib, "../x64/Release/DefectDetectionCpp.lib")
#pragma comment(lib, "../x64/Release/opencv_world455.lib")

namespace DefectDetectionCli {
	public ref class CliPrediction
	{
	public:
		Prediction* prediction;
		System::String^ paramPath;
		System::String^ modelPath;
		//System::String^ imgPath;
		array<int, 2>^ rectCoords;
		array<int>^ objectScore;
		array<int>^ objectLabels;
		array<int>^ qrcodeLabels;
		int imgStride;

		cv::Mat BitmapToCvMat(System::Drawing::Bitmap^ image);
		CliPrediction();
		~CliPrediction();
		int Predict(System::Drawing::Bitmap^ image);
	};
}

