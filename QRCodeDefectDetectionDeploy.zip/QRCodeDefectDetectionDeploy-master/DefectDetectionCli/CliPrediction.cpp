#include "CliPrediction.h"

DefectDetectionCli::CliPrediction::CliPrediction()
{
    prediction = new Prediction();
}

DefectDetectionCli::CliPrediction::~CliPrediction()
{
    delete prediction;
}


cv::Mat DefectDetectionCli::CliPrediction::BitmapToCvMat(System::Drawing::Bitmap^ image)
{
    cv::Mat dst;

    if (image == nullptr)
    {
        return dst;
    }

    int imgH = image->Height;
    int imgW = image->Width;

    int channel = 3;
    int imgtype = 0;

    if (image->PixelFormat == System::Drawing::Imaging::PixelFormat::Format8bppIndexed)
    {
        channel = 1;
        imgtype = CV_8UC1;
    }
    else if (image->PixelFormat == System::Drawing::Imaging::PixelFormat::Format24bppRgb)
    {
        channel = 3;
        imgtype = CV_8UC3;
    }
    else if (image->PixelFormat == System::Drawing::Imaging::PixelFormat::Format32bppArgb)
    {
        channel = 4;
        imgtype = CV_8UC4;
    }
    else
    {
        return dst;
    }

    System::Drawing::Imaging::BitmapData^ bitmapData = image->LockBits(System::Drawing::Rectangle(0, 0, imgW, imgH),
        System::Drawing::Imaging::ImageLockMode::ReadWrite, image->PixelFormat);
    int actualwidth = imgW * channel;
    int offset = bitmapData->Stride - actualwidth;

    int posScan = 0, posReal = 0;

    if (0 != offset)
    {
        int step = ((imgW * channel * 8 + 31) / 32) * 4;
        dst = cv::Mat(imgH, imgW, imgtype, (void*)(bitmapData->Scan0), step);
    }
    else
    {
        dst = cv::Mat(imgH, imgW, imgtype, (void*)(bitmapData->Scan0));
    }

    image->UnlockBits(bitmapData);

    return dst;
}

int DefectDetectionCli::CliPrediction::Predict(System::Drawing::Bitmap^ image)
{

    cv::Mat cvImage = BitmapToCvMat(image);
    if (cvImage.empty())
    {
        System::Console::WriteLine("Bitmap convert to cvMat failed!");
        return -1;
    }
    else
    {
        System::Console::WriteLine("Bitmap convert to cvMat sucessfully!");
    }

    prediction->GetModelPaths();

    System::String^ logger_convert = "Bitmap convert to cvMat sucessfully!";
    System::IO::File::AppendAllText(msclr::interop::marshal_as<System::String^>(prediction->logger_path), logger_convert + "\r\n");

    prediction->run(cvImage);

    int rowIndex = 0;
    int colIndex = 0;

    rectCoords = gcnew array<int, 2>(2, 4);
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            rectCoords[i, j] = prediction->detected_rect_coords[i][j];
        }
    }

    objectScore = gcnew array<int>(2);
    for (int i = 0; i < 2; i++)
    {
        objectScore[i] = prediction->object_scores[i];
    }

    qrcodeLabels = gcnew array<int>(2);
    for (int i = 0; i < 2; i++)
    {
        qrcodeLabels[i] = prediction->qrcode_labels[i];
    }

    System::String^ logger_prediction = "Prediction sucessfully!";
    System::IO::File::AppendAllText(msclr::interop::marshal_as<System::String^>(prediction->logger_path), "\r\n" + logger_prediction);

    System::Console::WriteLine("left: {0}, right: {1}", qrcodeLabels[0], qrcodeLabels[1]);

    return 0;
}
