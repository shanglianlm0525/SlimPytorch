﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using DefectDetectionCli;

namespace CSharpTest
{
    class Program
    {
        /// <summary>
        /// 获取目录下所有文件名
        /// </summary>
        /// <param name="rootPath">根路径</param>
        /// <returns></returns>
        private static List<string> GetFilePathList(string rootPath)
        {
            //文件集合
            List<string> flieList = new List<string>();
            //文件夹集合
            List<string> dirList = new List<string>();
            dirList.Add(rootPath);

            //foreach会提示：不能循环已经被修改的集合
            for (int i = 0; i < dirList.Count; i++)
            {
                if (Directory.Exists(dirList[i]))
                {
                    //添加文件夹下的文件夹
                    dirList.AddRange(Directory.GetDirectories(dirList[i]));
                    //添加文件下文件
                    flieList.AddRange(Directory.GetFiles(dirList[i]));
                }
            }
            return flieList;
        }

        static void Main(string[] args)
        {
            string imgs_dir = "D:\\Temp\\0711\\image2";
            List<string> imgsFilePaths = new List<string>(GetFilePathList(imgs_dir));

            for(int i = 0; i < imgsFilePaths.Count; ++i)
            {
                string imgName = System.IO.Path.GetFileName(imgsFilePaths[i]);

                Bitmap bmpImg = new Bitmap(imgsFilePaths[i]);

                DateTime dt1 = System.DateTime.Now;

                //CliPrediction cliPrediction = new CliPrediction(imgPath);
                CliPrediction cliPrediction = new CliPrediction();

                int value = cliPrediction.Predict(bmpImg);

                DateTime dt2 = System.DateTime.Now;

                TimeSpan ts = dt2.Subtract(dt1);
                Console.WriteLine("run time {0}", ts.TotalMilliseconds);

                Console.WriteLine("order: {0}, Image Name: {1}, left: {2}, right: {3}", 
                    i + 1, imgName, cliPrediction.qrcodeLabels[0], cliPrediction.qrcodeLabels[1]);

                int a = 1;
            }

            Console.ReadLine();
        }
    }
}
