#include "BoxInfo.h"

BoxInfo::BoxInfo()
{
	x1 = 0.0;
	y1 = 0.0;
	x2 = 0.0;
	y2 = 0.0;
	score = 0.0;
	label = 0;
}


BoxInfo::~BoxInfo()
{
}

