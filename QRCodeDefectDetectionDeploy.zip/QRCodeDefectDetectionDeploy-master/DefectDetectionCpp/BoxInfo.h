#pragma once

class BoxInfo
{
public:
	BoxInfo();
	~BoxInfo();

	float x1;
	float y1;
	float x2;
	float y2;
	float score;
	int label;
};

