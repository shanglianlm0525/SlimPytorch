#pragma once
class CenterPrior
{
public:
	CenterPrior();
	~CenterPrior();

	int x;
	int y;
	int stride;
};

