#pragma once
class ObjectRect
{
public:
	ObjectRect();
	~ObjectRect();

	int x;
	int y;
	int width;
	int height;
	float width_ratio;
	float height_ratio;

};