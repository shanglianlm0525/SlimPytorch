#include "Prediction.h"

Prediction::Prediction()
{
	detected_rect_coords[2][4] = { 0 };
	object_scores[2] = { 0.0 };
	object_labels[2] = { 0 };
	qrcode_labels[0] = -1;
	qrcode_labels[1] = -1;
}

// deinit 
Prediction::~Prediction() {

}

void Prediction::WriteToLogger(const std::string& logger_text)
{
	write_txt.open(logger_path, std::ios::out | std::ios::app);
	if (!write_txt.is_open())
	{
		printf("Create logger txt failed!\n");
	}

	write_txt << logger_text << "\r\n" << std::endl;

	write_txt.close();
}

void Prediction::WriteToLoggerIncludeVariable(const std::string& logger_text, std::string output_variable)
{
	write_txt.open(logger_path, std::ios::out | std::ios::app);
	if (!write_txt.is_open())
	{
		printf("Create logger txt failed!\n");
	}

	write_txt << logger_text << output_variable << "\r\n" << std::endl;

	write_txt.close();
}

void Prediction::GetModelPaths()
{
	//printf("Start find model paths!\n");
	
	char dll_buff[MAX_PATH] = { 0 };
	HMODULE h_module_instance = _AtlBaseModule.GetModuleInstance();
	GetModuleFileNameA(h_module_instance, dll_buff, MAX_PATH);

	//printf("Dll path: %s\n", dll_buff);

	std::string file_path = std::string(dll_buff);
	int index = file_path.find_last_of("\\");
	std::string folder_path = file_path.substr(0, index);

	//printf("Foleder path: %s\n", folder_path.c_str());

	big_det_param_file_path = folder_path + "\\" + kBigDetModelName + ".param";
	qrcode_cls_param_file_path = folder_path + "\\" + kQrcodeClsModelName + ".param";
	character_cls_param_file_path = folder_path + "\\" + kCharacterClsModelName + ".param";

	big_det_bin_file_path = folder_path + "\\" + kBigDetModelName + ".bin";
	qrcode_cls_bin_file_path = folder_path + "\\" + kQrcodeClsModelName + ".bin";
	character_cls_bin_file_path = folder_path + "\\" + kCharacterClsModelName + ".bin";

	//square_cls_bin_file_path = folder_path + "\\" + kSquareClsModelName + ".bin";
	//qrcode_det_bin_file_path = folder_path + "\\" + kQrcodeDetModelName + ".bin";

	cpp_dll_path = folder_path + "\\" + kCppDllName;

	logger_path = folder_path + "\\" + "logger.txt";
	//WriteToLogger("Create logger txt sucessfully!");
}

/*void Prediction::ReadBigImage()
{
	FILE* f = fopen(imgPath.c_str(), "rb");
	if (!f)
	{
		std::cout << "Image is not exist�� " << imgPath << std::endl;
		return;
	}
	fseek(f, 0, SEEK_END);  //seek to end of file
	size_t buffer_size = ftell(f);  // get current file pointer
	fseek(f, 0, SEEK_SET);  //seek back to beginning of file

	std::vector<char> buffer(buffer_size);
	fread(&buffer[0], sizeof(char), buffer_size, f);
	fclose(f);

	srcImage = cv::imdecode(buffer, cv::IMREAD_COLOR);
}*/

cv::Mat Prediction::GetRoiImage(const cv::Mat& input_image, int left_top_X,
	int left_top_Y, int roi_width, int roi_height)
{
	cv::Mat roiImage = cv::Mat::zeros(cv::Size(roi_width, roi_height), CV_8UC3);
	cv::Mat roiTempImage = input_image(cv::Rect(left_top_X, left_top_Y, roi_width, roi_height));
	roiTempImage.copyTo(roiImage);

	return roiImage;
}

int Prediction::DetectSingleQrcode(int box_index, int qrcode_num, Classification* qrcode_cls)
{
	int boxLocIndex = 0;
	if (box_index == 1 && qrcode_num == 1)  //Just one qrcode��may be include character��and qrcodr at big image center right side.
	{
		boxLocIndex = box_index - 1;
	}
	else
	{
		boxLocIndex = box_index;
	}

	int roi_width = qrcode_box_info[boxLocIndex].x2 + kCoordEndOffset - qrcode_box_info[boxLocIndex].x1 + kCoordStartOffset;
	int roi_height = qrcode_box_info[boxLocIndex].y2 + kCoordStartOffset - qrcode_box_info[boxLocIndex].y1 + kCoordStartOffset;
	int leftX = qrcode_box_info[boxLocIndex].x1 - kCoordStartOffset;
	int leftY = qrcode_box_info[boxLocIndex].y1 - kCoordStartOffset;

	cv::Mat qrcode_roi_image = GetRoiImage(copied_input_image, leftX, leftY, roi_width, roi_height);

	int qrcodeClsResult = qrcode_cls->run(qrcode_roi_image);
	if (qrcodeClsResult == 0)
	{
		qrcode_labels[box_index] = 0;
	}
	else
	{
		qrcode_labels[box_index] = 1;
	}

	//auto results_Square = qrcodeDetection->run(qrcode_roi_image);
	/*auto results_Square = qrcodeDetection.run(qrcode_roi_image);
	if (results_Square.size() != 3)
	{
		qrcode_labels[box_index] = 0;
	}
	else
	{
		for (int j = 0; j < results_Square.size(); ++j)
		{
			int roiWidth_Square = results_Square[j].x2 - results_Square[j].x1;
			int roiHeight_Square = results_Square[j].y2 - results_Square[j].y1;

			cv::Mat roiImage_Square = GetRoiImage(qrcode_roi_image, (int)results_Square[j].x1,
				(int)results_Square[j].y1, roiWidth_Square, roiHeight_Square);

			int squareClsResult = squareCls->run(roiImage_Square);
			//int squareClsResult = squareCls.run(roiImage_Square);
			if (squareClsResult == 0)
			{
				qrcode_labels[box_index] = 0;
				break;
			}
			else if (j == results_Square.size() - 1 && squareClsResult == 1)
			{
				int qrcodeClsResult = qrcode_img_cls->run(qrcode_roi_image);
				//int qrcodeClsResult = qrcode_img_cls.run(qrcode_roi_image);
				if (qrcodeClsResult == 0)
				{
					qrcode_labels[box_index] = 0;
				}
				else
				{
					qrcode_labels[box_index] = 1;
				}

			}
		}
	}*/

	return 0;
}

void Prediction::SwapVectorElements(std::vector<BoxInfo>& box_info)
{
	if (box_info.size() == 2 &&
		box_info[0].x1 > box_info[1].x1)
	{
		std::swap(box_info[0], box_info[1]);
	}
}

/*LPCWSTR Prediction::ConvertStringToLPCWSTR(const std::string& org_str)
{
	wchar_t* wcstring = 0;
	size_t origsize = org_str.length() + 1;
	const size_t newsize = 100;
	size_t convertedChars = 0;
	try
	{
		wchar_t* wcstring = (wchar_t*)malloc(sizeof(wchar_t) * (org_str.length() - 1));
		mbstowcs_s(&convertedChars, wcstring, origsize, org_str.c_str(), _TRUNCATE);
		return wcstring;
	}
	catch (std::exception e)
	{
		WriteToLoggerIncludeVariable("StringToLPCWSTR Error: ", e.what());
	}
}*/

LPCWSTR Prediction::ConvertStringToLPCWSTR(const std::string& org_str)
{
	try
	{
		int len = org_str.length();
		int lenbf = MultiByteToWideChar(CP_ACP, 0, org_str.c_str(), len, 0, 0);
		wchar_t* buffer = new wchar_t[sizeof(wchar_t) * lenbf];
		MultiByteToWideChar(CP_ACP, 0, org_str.c_str(), len, buffer, sizeof(wchar_t) * lenbf);
		buffer[len] = 0;
		return buffer;
	}
	catch (std::exception e)
	{
		WriteToLoggerIncludeVariable("StringToLPCWSTR Error: ", e.what());
	}
}


const char* Prediction::GetMemParamPtr(int resource_id)
{
	WriteToLoggerIncludeVariable("Path: ", cpp_dll_path);

	LPCWSTR converted_cpp_dll_path = ConvertStringToLPCWSTR(cpp_dll_path);

	//WriteToLogger("Convert string to LPCWSTR sucessfully!");

	HINSTANCE dll_instance = GetModuleHandle(converted_cpp_dll_path);

	//WriteToLogger("Dll instance create sucessfully!");

	char* param_ptr = NULL;
	HRSRC hrsrc = FindResource(dll_instance, MAKEINTRESOURCE(resource_id), TEXT("param"));
	//WriteToLogger("HRSRC create sucessfully!");

	if (NULL == hrsrc)
	{
		std::cout << "Find param resource failed!" << std::endl;
		WriteToLogger("Find param resource failed!");
		return param_ptr;
	}

	//WriteToLogger("Find param resource sucessfully!");

	DWORD dw_size = SizeofResource(dll_instance, hrsrc);
	if (0 == dw_size)
	{
		std::cout << "Param resource is empty!" << std::endl;
		return param_ptr;
	}

	//WriteToLogger("Param resource is exist!");

	HGLOBAL hglobal = LoadResource(dll_instance, hrsrc);
	if (NULL == hglobal)
	{
		std::cout << "Load param resource failed!" << std::endl;
		return param_ptr;
	}

	//WriteToLogger("Load param resource sucessfully!");

	LPVOID pbuffer = LockResource(hglobal);
	if (NULL == pbuffer)
	{
		std::cout << "Lock param resource failed!" << std::endl;
		return param_ptr;
	}

	//WriteToLogger("Lock param resource sucessfully!");

	param_ptr = (char*)pbuffer;

	return param_ptr;
}

void Prediction::Predict()
{
	int bigImageWidth = copied_input_image.cols;

	//const char* detParameterPtr_Big = GetMemParamPtr(kBigDetParamId);
	//const char* clsParameterPtr_Character = GetMemParamPtr(kCharacterClsParamId);
	//const char* clsParameterPtr_Qrcode = GetMemParamPtr(kQrcodeClsParamId);
	//const char* detParameterPtr_Qrcode = GetMemParamPtr(102);
	//const char* clsParameterPtr_Square = GetMemParamPtr(105);

	//printf("Param models load sucessfully!\n");

	//WriteToLogger("Param models load sucessfully!");

	//logger->info("Param models load sucessfully!");

	Detection* big_img_det = new Detection(big_det_param_file_path.c_str(), big_det_bin_file_path.c_str(),
		kBigDetResizedWidth, kBigDetResizedHeight, kBigDetClassNum, kBigImageLabelNames);
	Classification* qrcode_img_cls = new Classification(qrcode_cls_param_file_path.c_str(), qrcode_cls_bin_file_path.c_str(),
		kQrcodeClsResizedWidth, kQrcodeClsResizedHeight);
	Classification* character_img_cls = new Classification(character_cls_param_file_path.c_str(), character_cls_bin_file_path.c_str(),
		kCharacterClsResizedWidth, kCharacterClsResizedHeight);

	/*Detection* big_img_det = new Detection(detParameterPtr_Big, big_det_bin_file_path.c_str(),
		kBigDetResizedWidth, kBigDetResizedHeight, kBigDetClassNum, kBigImageLabelNames);
	Classification* qrcode_img_cls = new Classification(clsParameterPtr_Qrcode, qrcode_cls_bin_file_path.c_str(),
		kQrcodeClsResizedWidth, kQrcodeClsResizedHeight);
	Classification* character_img_cls = new Classification(clsParameterPtr_Character, character_cls_bin_file_path.c_str(),
		kCharacterClsResizedWidth, kCharacterClsResizedHeight);*/

	//printf("Det and cls objects create sucessfully!\n");

	//WriteToLogger("Det and cls objects create sucessfully!");

	/*Detection* qrcodeDetection = new Detection(detParameterPtr_Qrcode, qrcode_det_bin_file_path.c_str(),
		kQrcodeDetResizedWidth, kQrcodeDetResizedHeight, kQrcodeDetClassNum, qrcode_image_label_names);
	Classification* squareCls = new Classification(clsParameterPtr_Square, square_cls_bin_file_path.c_str(),
		kSquareClsResizedWidth, kSquareClsResizedHeight);*/

	auto results_big_img = big_img_det->run(copied_input_image);

	//printf("Big image detection sucessfully!\n");

	//WriteToLogger("Big image detection sucessfully!");

	int boxNum = results_big_img.size();
	for (int i = 0; i < boxNum; ++i)
	{
		if (results_big_img[i].label == 1)
		{
			qrcode_box_info.push_back(results_big_img[i]);
		}
		else if (results_big_img[i].label == 2)
		{
			character_box_info.push_back(results_big_img[i]);
		}
	}

	SwapVectorElements(qrcode_box_info);
	SwapVectorElements(character_box_info);

	int num_qrcode_boxes = qrcode_box_info.size();
	int num_character_boxes = character_box_info.size();

	int justOneQrcodeIndex = 0;
	float widthRatio = 0.75;
	if (num_qrcode_boxes == 1)
	{
		if (qrcode_box_info[0].x2 > bigImageWidth * widthRatio)
		{
			justOneQrcodeIndex = 1;
		}
	}

	if ((num_qrcode_boxes == 1 || num_qrcode_boxes == 2) && num_character_boxes == 0)  // Just have qrcode
	{
		if (num_qrcode_boxes == 1)
		{
			DetectSingleQrcode(justOneQrcodeIndex, num_qrcode_boxes, qrcode_img_cls);
		}
		else
		{
			for (int i = 0; i < num_qrcode_boxes; ++i)
			{
				DetectSingleQrcode(i, num_qrcode_boxes, qrcode_img_cls);
			}
		}
	}
	else if ((num_qrcode_boxes == 1 && num_character_boxes == 1) ||
		(num_qrcode_boxes == 2 && num_character_boxes == 2))  // Include qrcode and character
	{
		for (int i = 0; i < num_character_boxes; ++i)
		{
			int roiWidth_Character = character_box_info[i].x2 + kCoordEndOffset - character_box_info[i].x1 + kCoordStartOffset;
			int roiHeight_Character = character_box_info[i].y2 + kCoordEndOffset - character_box_info[i].y1 - kCoordStartOffset;
			int leftX_Character = character_box_info[i].x1 - kCoordStartOffset;
			int leftY_Character = character_box_info[i].y1 + kCoordStartOffset;

			cv::Mat roiImage_Character = GetRoiImage(copied_input_image, leftX_Character, leftY_Character, roiWidth_Character, roiHeight_Character);

			int characterClsResult = character_img_cls->run(roiImage_Character);

			if (characterClsResult == 0)
			{
				if (num_qrcode_boxes == 1)
				{
					qrcode_labels[justOneQrcodeIndex] = 0;
				}
				else
				{
					qrcode_labels[i] = 0;
				}
			}
			else
			{
				if (num_qrcode_boxes == 1)
				{
					DetectSingleQrcode(justOneQrcodeIndex, num_qrcode_boxes, qrcode_img_cls);
				}
				else
				{
					DetectSingleQrcode(i, num_qrcode_boxes, qrcode_img_cls);
				}
			}
		}
	}
	else if (num_qrcode_boxes == 0 && num_character_boxes == 0)  // None
	{
		qrcode_labels[0] = -1;
		qrcode_labels[1] = -1;
	}
	else  // abnormality
	{
		qrcode_labels[0] = -2;
		qrcode_labels[1] = -2;
	}

	delete big_img_det;
	//delete qrcodeDetection;
	//delete squareCls;
	delete qrcode_img_cls;
	delete character_img_cls;
	big_img_det = NULL;
	qrcode_img_cls = NULL;
	character_img_cls = NULL;

	//printf("Other models predict sucessfully!\n");

	//WriteToLogger("Cls sucessfully!");
}

int Prediction::run(const cv::Mat& input_bmp_image)
{	
	input_bmp_image.copyTo(copied_input_image);
	//cv::cvtColor(inputImage, colorImage, cv::COLOR_GRAY2BGR);
	//printf("Color transform sucessfully!\n");

	//GetModelPaths();

	//printf("Get predict models sucessfully!\n");

	//WriteToLogger("Get predict models sucessfully!");

	//ReadBigImage();

	Predict();

	return 0;
}
