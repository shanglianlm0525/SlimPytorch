#include "Detection.h"


//Detection* Detection::objDetector = nullptr;
Detection::Detection(const char* param_file_contents, const char* bin_file_path,
	int input_resized_width, int input_resized_height,
	int input_class_num, std::vector<std::string> input_label_names)
{
	detection_network.opt.use_vulkan_compute = false;
	detection_network.opt.use_fp16_arithmetic = true;

	if (NULL == param_file_contents)
	{
		printf("There is a problem with the param file!\n");
	}

	if (_access(bin_file_path, 0) == -1) {
		printf("file %s is not exist!\n", bin_file_path);
	}

	//detection_network.load_param_mem(param_file_contents);
	detection_network.load_param(param_file_contents);
	detection_network.load_model(bin_file_path);

	resized_width = input_resized_width;
	resized_height = input_resized_height;
	class_num = input_class_num;
	label_names.assign(input_label_names.begin(), input_label_names.end());
}

Detection::~Detection()
{
	in.release();
	out.release();
}

inline float fast_exp(float x)
{
	union {
		uint32_t i;
		float f;
	} v{};
	v.i = (1 << 23) * (1.4426950409 * x + 126.93490512f);
	return v.f;
}

inline float sigmoid(float x)
{
	return 1.0f / (1.0f + fast_exp(-x));
}

template<typename _Tp>
int activation_function_softmax(const _Tp* src, _Tp* dst, int length)
{
	const _Tp alpha = *std::max_element(src, src + length);
	_Tp denominator{ 0 };

	for (int i = 0; i < length; ++i) {
		dst[i] = fast_exp(src[i] - alpha);
		denominator += dst[i];
	}

	for (int i = 0; i < length; ++i) {
		dst[i] /= denominator;
	}

	return 0;
}

static void generate_grid_center_priors(const int input_height, const int input_width,
	std::vector<int>& strides, std::vector<CenterPrior>& center_priors)
{
	center_priors.clear();
	int i, x, y;
	int stride, feat_w, feat_h;
	for (i = 0; i < (int)strides.size(); i++)
	{
		stride = strides[i];
		feat_w = ceil((float)input_width / stride);
		feat_h = ceil((float)input_height / stride);
		for (y = 0; y < feat_h; y++)
		{
			for (x = 0; x < feat_w; x++)
			{
				CenterPrior ct;
				ct.x = x;
				ct.y = y;
				ct.stride = stride;
				center_priors.push_back(ct);
			}
		}
	}
}

int Detection::ResizeUniform(const cv::Mat& src_image, cv::Size resized_width_heigth, cv::Mat& dst_image)
{
	effect_roi.x = 0;
	effect_roi.y = 0;
	effect_roi.width = 0;
	effect_roi.height = 0;

	int w = src_image.cols;
	int h = src_image.rows;
	int dst_w = resized_width_heigth.width;
	int dst_h = resized_width_heigth.height;
	//std::cout << "src_image: (" << h << ", " << w << ")" << std::endl;
	dst_image = cv::Mat(cv::Size(dst_w, dst_h), CV_8UC3, cv::Scalar(0));

	float ratio_src = w * 1.0 / h;
	float ratio_dst = dst_w * 1.0 / dst_h;

	int tmp_w = 0;
	int tmp_h = 0;
	if (ratio_src > ratio_dst) {
		tmp_w = dst_w;
		tmp_h = floor((dst_w * 1.0 / w) * h);
	}
	else if (ratio_src < ratio_dst) {
		tmp_h = dst_h;
		tmp_w = floor((dst_h * 1.0 / h) * w);
	}
	else {
		cv::resize(src_image, dst_image, resized_width_heigth);
		effect_roi.x = 0;
		effect_roi.y = 0;
		effect_roi.width = dst_w;
		effect_roi.height = dst_h;
		effect_roi.width_ratio = (float)w / (float)dst_w;
		effect_roi.height_ratio = (float)h / (float)dst_h;
		return 0;
	}

	//std::cout << "tmp: (" << tmp_h << ", " << tmp_w << ")" << std::endl;
	cv::Mat tmp;
	cv::resize(src_image, tmp, cv::Size(tmp_w, tmp_h));

	if (tmp_w != dst_w) {
		int index_w = floor((dst_w - tmp_w) / 2.0);
		//std::cout << "index_w: " << index_w << std::endl;
		for (int i = 0; i < dst_h; i++) {
			memcpy(dst_image.data + i * dst_w * 3 + index_w * 3, tmp.data + i * tmp_w * 3, tmp_w * 3);
		}
		effect_roi.x = index_w;
		effect_roi.y = 0;
		effect_roi.width = tmp_w;
		effect_roi.height = tmp_h;
		effect_roi.width_ratio = (float)w / (float)tmp_w;
		effect_roi.height_ratio = (float)h / (float)tmp_h;
	}
	else if (tmp_h != dst_h) {
		int index_h = floor((dst_h - tmp_h) / 2.0);
		//std::cout << "index_h: " << index_h << std::endl;
		memcpy(dst_image.data + index_h * dst_w * 3, tmp.data, tmp_w * tmp_h * 3);
		effect_roi.x = 0;
		effect_roi.y = index_h;
		effect_roi.width = tmp_w;
		effect_roi.height = tmp_h;
		effect_roi.width_ratio = (float)w / (float)tmp_w;
		effect_roi.height_ratio = (float)h / (float)tmp_h;
	}
	else {
		printf("error\n");
	}
	//cv::imshow("dst_image", dst_image);
	//cv::waitKey(0);
	return 0;
}


void Detection::Preprocess(const cv::Mat& src_image, ncnn::Mat& in)
{
	ResizeUniform(src_image, cv::Size(resized_width, resized_height), resized_image);
	// int img_w = image.cols;
	// int img_h = image.rows;

	in = ncnn::Mat::from_pixels(resized_image.data, ncnn::Mat::PIXEL_BGR, resized_width, resized_height);
	//in = ncnn::Mat::from_pixels_resize(image.data, ncnn::Mat::PIXEL_BGR, img_w, img_h, input_width, input_height);

	in.substract_mean_normalize(kMeanValues, kNormValues);
}


void Detection::DecodeInference(const ncnn::Mat& features, const std::vector<CenterPrior>& center_priors,
	float infer_threshold, std::vector<std::vector<BoxInfo>>& infer_results)
{
	const int num_points = center_priors.size();
	//printf("num_points:%d\n", num_points);

	//cv::Mat debug_heatmap = cv::Mat(feature_h, feature_w, CV_8UC3);
	for (int idx = 0; idx < num_points; idx++)
	{
		const int ct_x = center_priors[idx].x;
		const int ct_y = center_priors[idx].y;
		const int stride = center_priors[idx].stride;

		const float* scores = features.row(idx);
		float score = 0;
		int cur_label = 0;
		for (int label = 0; label < class_num; label++)
		{
			if (scores[label] > score)
			{
				score = scores[label];
				cur_label = label;
			}
		}
		if (score > infer_threshold)
		{
			//std::cout << "label:" << cur_label << " score:" << score << std::endl;
			const float* bbox_pred = features.row(idx) + class_num;
			infer_results[cur_label].push_back(ConvertPredsToBoxInfo(bbox_pred, cur_label, score, ct_x, ct_y, stride));
			//debug_heatmap.at<cv::Vec3b>(row, col)[0] = 255;
			//cv::imshow("debug", debug_heatmap);
		}
	}
}

BoxInfo Detection::ConvertPredsToBoxInfo(const float*& dfl_det, int label, float score,
	int x, int y, int stride)
{
	BoxInfo boxInfo;

	float ct_x = x * stride;
	float ct_y = y * stride;
	std::vector<float> dis_pred;
	dis_pred.resize(4);

	int i, j;
	float dis;
	for (i = 0; i < 4; i++)
	{
		dis = 0;
		float* dis_after_sm = new float[kRegMax + 1];
		activation_function_softmax(dfl_det + i * (kRegMax + 1), dis_after_sm, kRegMax + 1);
		for (j = 0; j < kRegMax + 1; j++)
		{
			dis += j * dis_after_sm[j];
		}
		dis *= stride;
		//std::cout << "dis:" << dis << std::endl;
		dis_pred[i] = dis;
		delete[] dis_after_sm;
	}
	float xmin = (std::max)(ct_x - dis_pred[0], .0f);
	float ymin = (std::max)(ct_y - dis_pred[1], .0f);
	float xmax = (std::min)(ct_x + dis_pred[2], (float)resized_width);
	float ymax = (std::min)(ct_y + dis_pred[3], (float)resized_height);

	//std::cout << xmin << "," << ymin << "," << xmax << "," << xmax << "," << std::endl;
	boxInfo.x1 = xmin;
	boxInfo.y1 = ymin;
	boxInfo.x2 = xmax;
	boxInfo.y2 = ymax;
	boxInfo.score = score;
	boxInfo.label = label;

	//return BoxInfo{ xmin, ymin, xmax, ymax, score, label };
	return boxInfo;
}

void Detection::nms(std::vector<BoxInfo>& input_boxes, float NMS_THRESH)
{
	std::sort(input_boxes.begin(), input_boxes.end(), [](BoxInfo a, BoxInfo b) { return a.score > b.score; });
	std::vector<float> vArea(input_boxes.size());
	int i, j;
	for (i = 0; i < int(input_boxes.size()); ++i) {
		vArea[i] = (input_boxes.at(i).x2 - input_boxes.at(i).x1 + 1)
			* (input_boxes.at(i).y2 - input_boxes.at(i).y1 + 1);
	}

	float xx1, yy1, xx2, yy2;
	float w, h, inter, ovr;
	for (i = 0; i < int(input_boxes.size()); ++i) {
		for (j = i + 1; j < int(input_boxes.size());) {
			xx1 = (std::max)(input_boxes[i].x1, input_boxes[j].x1);
			yy1 = (std::max)(input_boxes[i].y1, input_boxes[j].y1);
			xx2 = (std::min)(input_boxes[i].x2, input_boxes[j].x2);
			yy2 = (std::min)(input_boxes[i].y2, input_boxes[j].y2);
			w = (std::max)(float(0), xx2 - xx1 + 1);
			h = (std::max)(float(0), yy2 - yy1 + 1);
			inter = w * h;
			ovr = inter / (vArea[i] + vArea[j] - inter);
			if (ovr >= NMS_THRESH) {
				input_boxes.erase(input_boxes.begin() + j);
				vArea.erase(vArea.begin() + j);
			}
			else {
				j++;
			}
		}
	}
}


std::vector<BoxInfo> Detection::run(const cv::Mat& input_image)
{
	Preprocess(input_image, in);

	// auto ex = Net->create_extractor();
	extractor = detection_network.create_extractor();
	extractor.set_light_mode(false);
	extractor.set_num_threads(4);

	extractor.input("data", in);
	extractor.extract("output", out);
	// printf("%d %d %d \n", out.w, out.h, out.c);

	// generate center priors in format of (x, y, stride)
	generate_grid_center_priors(resized_width, resized_height, multi_level_strides, center_priors);

	infer_box_info.clear();
	infer_box_info.resize(class_num);
	DecodeInference(out, center_priors, fScoreThreshold, infer_box_info);

	detected_results.clear();
	for (int i = 0; i < (int)infer_box_info.size(); i++)
	{
		nms(infer_box_info[i], fNmsThreshold);

		for (auto box : infer_box_info[i])
		{
			box.x1 = (box.x1 - effect_roi.x) * effect_roi.width_ratio;
			box.y1 = (box.y1 - effect_roi.y) * effect_roi.height_ratio;
			box.x2 = (box.x2 - effect_roi.x) * effect_roi.width_ratio;
			box.y2 = (box.y2 - effect_roi.y) * effect_roi.height_ratio;
			detected_results.push_back(box);
		}
	}

	return detected_results;
}


