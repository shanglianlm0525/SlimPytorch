#include "CenterPrior.h"

CenterPrior::CenterPrior()
{
	x = 0;
	y = 0;
	stride = 0;
}


CenterPrior::~CenterPrior()
{
}
