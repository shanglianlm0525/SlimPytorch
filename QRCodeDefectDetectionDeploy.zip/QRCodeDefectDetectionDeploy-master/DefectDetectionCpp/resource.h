//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� DefectDetectionCpp.rc ʹ��
//
#define IDR_PARAM_DET_BIG               101
#define IDR_PARAM_DET_QRCODE            102
#define IDR_PARAM_CLS_SQUARE            105
#define IDR_PARAM_CLS_CHARACTER         106
#define IDR_PARAM_CLS_QRCODE            107

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
