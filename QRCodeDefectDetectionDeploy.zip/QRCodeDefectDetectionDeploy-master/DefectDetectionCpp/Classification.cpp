#include "Classification.h"

// init
Classification::Classification(const char* param_file_contents, const char* bin_file_path,
	int input_resized_width, int input_resized_height)
{
	/*if (_access(parampath, 0) == -1) {
		printf("file %s is not exist!\n", parampath);
	}*/

	if (NULL == param_file_contents)
	{
		printf("There is a problem with the param file!\n");
	}

	if (_access(bin_file_path, 0) == -1) {
		printf("file %s is not exist!\n", bin_file_path);
	}

	//clssification_network.load_param_mem(param_file_contents);
	clssification_network.load_param(param_file_contents);
	clssification_network.load_model(bin_file_path);

	resized_width = input_resized_width;
	resized_height = input_resized_height;
}

// deinit 
Classification::~Classification() {

	in.release();
	out.release();
	//delete softmax;
}

// run
int Classification::run(const cv::Mat& input_image) {

	in = ncnn::Mat::from_pixels_resize(input_image.data, ncnn::Mat::PIXEL_BGR2RGB,
		input_image.cols, input_image.rows, resized_width, resized_height);
	//����pytorch�������б�׼��

	// in.substract_mean_normalize(kMeanValues, kStdValues);
	in.substract_mean_normalize(0, kNormalization);

	extractor = clssification_network.create_extractor();
	extractor.input(kInputNodeName, in);//input �� .param�ļ�������ڵ�����
	extractor.extract(kOutputNodeName, out);
	//ex.extract(outBlobName.c_str(), out);

	// manually call softmax on the fc output
	// convert result into probability
	// skip if your model already has softmax operation
	{
		ncnn::Layer* softmax = ncnn::create_layer("Softmax");
		ncnn::ParamDict pd;
		softmax->load_param(pd);
		softmax->forward_inplace(out, clssification_network.opt);
		delete softmax;
	}
	out = out.reshape(out.h * out.w * out.c);

	// trans output
	predicted_scores.clear();
	predicted_scores.resize(out.w);

	for (int j = 0; j < out.w; j++)
	{
		predicted_scores[j] = out[j];
	}

	/*int result_label = 1;
	if (predicted_scores[0] > kScoreThreshold)
	{
		result_label = 0;
	}

	return result_label;*/

	int maxIndex = (int)(std::max_element(predicted_scores.begin(),
		predicted_scores.end()) - predicted_scores.begin());

	return maxIndex;

	
}
