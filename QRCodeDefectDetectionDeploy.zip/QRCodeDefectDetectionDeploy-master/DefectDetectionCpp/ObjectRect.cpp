#include "ObjectRect.h"

ObjectRect::ObjectRect()
{
	x = 0;
	y = 0;
	width = 0;
	height = 0;
	width_ratio = 0.0;
	height_ratio = 0.0;
}


ObjectRect::~ObjectRect()
{
}
