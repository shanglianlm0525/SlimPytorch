#include "Prediction.h"
#include "resource.h"
#include <net.h>

const int color_list[80][3] =
{
	//{255 ,255 ,255}, //bg
	{ 216 , 82 , 24 },
	{ 236 ,176 , 31 },
	{ 125 , 46 ,141 },
	{ 118 ,171 , 47 },
	{ 76 ,189 ,237 },
	{ 238 , 19 , 46 },
	{ 76 , 76 , 76 },
	{ 153 ,153 ,153 },
	{ 255 ,  0 ,  0 },
	{ 255 ,127 ,  0 },
	{ 190 ,190 ,  0 },
	{ 0 ,255 ,  0 },
	{ 0 ,  0 ,255 },
	{ 170 ,  0 ,255 },
	{ 84 , 84 ,  0 },
	{ 84 ,170 ,  0 },
	{ 84 ,255 ,  0 },
	{ 170 , 84 ,  0 },
	{ 170 ,170 ,  0 },
	{ 170 ,255 ,  0 },
	{ 255 , 84 ,  0 },
	{ 255 ,170 ,  0 },
	{ 255 ,255 ,  0 },
	{ 0 , 84 ,127 },
	{ 0 ,170 ,127 },
	{ 0 ,255 ,127 },
	{ 84 ,  0 ,127 },
	{ 84 , 84 ,127 },
	{ 84 ,170 ,127 },
	{ 84 ,255 ,127 },
	{ 170 ,  0 ,127 },
	{ 170 , 84 ,127 },
	{ 170 ,170 ,127 },
	{ 170 ,255 ,127 },
	{ 255 ,  0 ,127 },
	{ 255 , 84 ,127 },
	{ 255 ,170 ,127 },
	{ 255 ,255 ,127 },
	{ 0 , 84 ,255 },
	{ 0 ,170 ,255 },
	{ 0 ,255 ,255 },
	{ 84 ,  0 ,255 },
	{ 84 , 84 ,255 },
	{ 84 ,170 ,255 },
	{ 84 ,255 ,255 },
	{ 170 ,  0 ,255 },
	{ 170 , 84 ,255 },
	{ 170 ,170 ,255 },
	{ 170 ,255 ,255 },
	{ 255 ,  0 ,255 },
	{ 255 , 84 ,255 },
	{ 255 ,170 ,255 },
	{ 42 ,  0 ,  0 },
	{ 84 ,  0 ,  0 },
	{ 127 ,  0 ,  0 },
	{ 170 ,  0 ,  0 },
	{ 212 ,  0 ,  0 },
	{ 255 ,  0 ,  0 },
	{ 0 , 42 ,  0 },
	{ 0 , 84 ,  0 },
	{ 0 ,127 ,  0 },
	{ 0 ,170 ,  0 },
	{ 0 ,212 ,  0 },
	{ 0 ,255 ,  0 },
	{ 0 ,  0 , 42 },
	{ 0 ,  0 , 84 },
	{ 0 ,  0 ,127 },
	{ 0 ,  0 ,170 },
	{ 0 ,  0 ,212 },
	{ 0 ,  0 ,255 },
	{ 0 ,  0 ,  0 },
	{ 36 , 36 , 36 },
	{ 72 , 72 , 72 },
	{ 109 ,109 ,109 },
	{ 145 ,145 ,145 },
	{ 182 ,182 ,182 },
	{ 218 ,218 ,218 },
	{ 0 ,113 ,188 },
	{ 80 ,182 ,188 },
	{ 127 ,127 ,  0 },
};

void draw_bboxes(const cv::Mat& bgr, const std::vector<BoxInfo>& bboxes, const std::string savePath, int qrcodeLabels[2])
{
	static const char* class_names[] = { "NG", "OK" };

	cv::Mat image = bgr.clone();
	int src_w = image.cols;
	int src_h = image.rows;
	int index = 0;

	for (size_t i = 0; i < bboxes.size(); i++)
	{
		const BoxInfo& bbox = bboxes[i];
		cv::Scalar color = cv::Scalar(color_list[bbox.label][0], color_list[bbox.label][1], color_list[bbox.label][2]);

		if (bbox.x1 != 0 && bbox.y1 != 0)
		{
			cv::rectangle(image, cv::Rect(cv::Point(bbox.x1, bbox.y1), cv::Point(bbox.x2, bbox.y2)), color, 2);

			char text[256];
			//sprintf(text, "%s: %.2f%", class_names[bbox.label], bbox.score);
			if (bbox.label == 1 && qrcodeLabels[index] >= 0)
			{
				std::string currentLabel(class_names[qrcodeLabels[index]]);
				std::string resultFormat("%s: %.2f");
				sprintf_s(text, sizeof(text), resultFormat.c_str(), currentLabel.c_str(), bbox.score);

				cv::putText(image, text, cv::Point(bbox.x1, bbox.y1), cv::FONT_HERSHEY_COMPLEX, 1.5, cv::Scalar(255, 0, 0), 2, 8);

				index++;
			}
		}
	}

	//cv::resize(image, image, cv::Size(1280, 960));
	//cv::imshow("image", image);

	cv::imwrite(savePath, image);

}

void GetAllFormatFiles(std::string path, std::vector<std::string>& files, std::string format)
{
	//�ļ����
	intptr_t hFile = 0;
	//�ļ���Ϣ
	struct _finddata_t fileinfo;
	std::string p;
	if ((hFile = _findfirst(p.assign(path).append("\\*" + format).c_str(), &fileinfo)) != -1)
	{
		do
		{
			if ((fileinfo.attrib & _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
				{
					//files.push_back(p.assign(path).append("\\").append(fileinfo.name) );
					GetAllFormatFiles(p.assign(path).append("\\").append(fileinfo.name), files, format);
				}

			}
			else
			{
				files.push_back(p.assign(path).append("\\").append(fileinfo.name));
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}

int main()
{
	//std::string imagePath = "D:\\WorkTask-2022\\QRcode_Printing_Quality_Detection\\3_Test\\0616\\data\\ZeroQrcode\\2022_04_08_12h12m16s246.jpg";
	//std::string imagePath = "D:\\WorkTask-2022\\QRcode_Printing_Quality_Detection\\3_Test\\0616\\data\\OneQrcode\\2022_04_21_08h52m13s281.jpg";
	std::string imagePath = "D:\\WorkTask-2022\\QRcode_Printing_Quality_Detection\\3_Test\\0616\\data\\two-OK\\2022_04_20_17h05m40s432.jpg";
	std::string imgPath = "D:\\Temp\\0704\\2022_04_02_15h15m30s451.bmp";
	cv::Mat bmpImage = cv::imread(imgPath);

	Prediction prediction;

	int value = prediction.run(bmpImage);

	return 0;

}