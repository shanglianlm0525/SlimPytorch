#pragma once
#include <io.h>
#include <opencv2/opencv.hpp>
#include <net.h>

class Classification
{
public:
	Classification(const char* param_file_contents, const char* bin_file_path,
		int input_resized_width, int input_resized_height);
	virtual ~Classification();
	int run(const cv::Mat& input_image);

private:
	int resized_width;
	int resized_height;

	//const float kMeanValues[3] = { 0.485f, 0.456f, 0.406f };
	//const float kStdValues[3] = { 1 / 0.229f, 1 / 0.224f, 1 / 0.225f };
	const float kNormalization[3] = { 1 / 255.0f, 1 / 255.0f, 1 / 255.0f };
	const char* kInputNodeName = "input.1";
	const char* kOutputNodeName = "852";
	const float kScoreThreshold = 0.6;

	ncnn::Net clssification_network;
	ncnn::Mat in;
	ncnn::Mat out;
	ncnn::Extractor extractor = clssification_network.create_extractor();

	std::vector<float> predicted_scores;
};

