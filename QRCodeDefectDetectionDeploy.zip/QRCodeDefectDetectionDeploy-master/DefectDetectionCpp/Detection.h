#pragma once
#include <opencv2/opencv.hpp>
#include <net.h>
#include <io.h>
#include "CenterPrior.h"
#include "BoxInfo.h"
#include "ObjectRect.h"

class Detection
{
public:
	Detection(const char* param_file_contents, const char* bin_file_path,
		int input_resized_width, int input_resized_height,
		int input_class_num, std::vector<std::string> input_label_names);
	virtual ~Detection();

	std::vector<BoxInfo> run(const cv::Mat& input_image);

private:
	//static ObjectDetect* objDetector;
	int resized_width;
	int resized_height;
	int class_num; // number of classes. 80 for COCO

	// modify these parameters to the same with your config if you want to use your own model
	const int kRegMax = 7; // `reg_max` set in the training config. Default: 7.
	const float kMeanValues[3] = { 103.53f, 116.28f, 123.675f };
	const float kNormValues[3] = { 0.017429f, 0.017507f, 0.017125f };
	const float fScoreThreshold = 0.5;
	const float fNmsThreshold = 0.5;

	ncnn::Net detection_network;
	ncnn::Mat in, out;
	ncnn::Extractor extractor = detection_network.create_extractor();

	std::vector<std::vector<BoxInfo>> infer_box_info;
	std::vector<CenterPrior> center_priors;
	std::vector<BoxInfo> detected_results;
	std::vector<std::string> label_names;
	std::vector<int> multi_level_strides = { 8, 16, 32, 64 }; // strides of the multi-level feature.

	ObjectRect effect_roi;
	cv::Mat resized_image;

	int ResizeUniform(const cv::Mat& src_image, cv::Size resized_width_heigth, cv::Mat& dst_image);
	void Preprocess(const cv::Mat& src_image, ncnn::Mat& in);
	void DecodeInference(const ncnn::Mat& features, const std::vector<CenterPrior>& center_priors,
		float infer_threshold, std::vector<std::vector<BoxInfo>>& infer_results);
	BoxInfo ConvertPredsToBoxInfo(const float*& dfl_det, int label, float score,
		int x, int y, int stride);
	static void nms(std::vector<BoxInfo>& result, float nms_threshold);
};
