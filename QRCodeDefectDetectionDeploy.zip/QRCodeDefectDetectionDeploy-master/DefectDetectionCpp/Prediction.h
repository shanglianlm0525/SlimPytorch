#pragma once
#include <iostream>
#include <fstream>
#include <atlbase.h>
#include <atlwin.h>
#include <iostream>
#include "Classification.h"
#include "Detection.h"
#include <net.h>
#include "resource.h"

#ifdef CPPDLL_EXPORTS
#define CPP_EXPORTS _declspec(dllexport)
#else
#define CPP_EXPORTS _declspec(dllimport)
#endif


extern "C" class CPP_EXPORTS Prediction
//class Prediction
{
private:
	std::ofstream write_txt;

	//static ObjectDetect* objDetector;
	const std::string kCppDllName = "DefectDetectionCpp.dll";

	// Models Name
	const std::string kBigDetModelName = "qrcode_det_0614";
	const std::string kQrcodeClsModelName = "qrcode_cls_sim_0719";
	const std::string kCharacterClsModelName = "character_cls_sim_0711_new";
	//const std::string kQrcodeDetModelName = "qrcode_det_single_0616";
	//const std::string kSquareClsModelName = "square_cls_simple_0616";

	const int kCoordStartOffset = 5;  // ROI image box start coodinate offset value
	const int kCoordEndOffset = 10;  // ROI image box end coodinate offset value

	//Resized width, Resized height
	const int kBigDetResizedWidth = 320;
	const int kBigDetResizedHeight = 320;
	//const int kQrcodeDetResizedWidth = 288;
	//const int kQrcodeDetResizedHeight = 288;

	const int kQrcodeClsResizedWidth = 288;
	const int kQrcodeClsResizedHeight = 288;
	const int kCharacterClsResizedWidth = 320;
	const int kCharacterClsResizedHeight = 128;
	//const int kSquareClsResizedWidth = 64;
	//const int kSquareClsResizedHeight = 64;

	const int kBigDetParamId = 101;
	const int kCharacterClsParamId = 106;
	const int kQrcodeClsParamId = 107;
	//const int kQrcodeDetParamId = 101;
	//const int kSquareClsParamId = 101;

	//Param files path
	std::string big_det_param_file_path;
	std::string qrcode_cls_param_file_path;
	std::string character_cls_param_file_path;

	//Bin files path
	std::string big_det_bin_file_path;
	std::string qrcode_cls_bin_file_path;
	std::string character_cls_bin_file_path;
	//std::string square_cls_bin_file_path;	
	//std::string qrcode_det_bin_file_path;

	cv::Mat copied_input_image;
	//std::string imgPath;
	//cv::Mat colorImage;

	//Class Num
	const int kBigDetClassNum = 3;
	const int kQrcodeDetClassNum = 1;
	const std::vector<std::string> kBigImageLabelNames{ "maoding", "erweima", "character" };
	//std::vector<std::string> qrcode_image_label_names{ "square" };

	std::string cpp_dll_path;

	
	//void ReadBigImage();
	cv::Mat GetRoiImage(const cv::Mat& input_image, int left_top_X,
		int left_top_Y, int roi_width, int roi_height);

	int DetectSingleQrcode(int box_index, int qrcode_num, Classification* qrcode_cls);
	void SwapVectorElements(std::vector<BoxInfo>& box_info);
	const char* GetMemParamPtr(int resource_id);
	LPCWSTR ConvertStringToLPCWSTR(const std::string& org_str);
	void Predict();
	void WriteToLogger(const std::string& logger_text);
	void WriteToLoggerIncludeVariable(const std::string& logger_text, std::string output_variable);
public:
	//std::shared_ptr<spdlog::logger> logger;
	//cv::Mat srcGrayImage;
	std::vector<BoxInfo> qrcode_box_info;
	std::vector<BoxInfo> character_box_info;
	Prediction();
	~Prediction();
	int detected_rect_coords[2][4];
	float object_scores[2];
	int object_labels[2];
	int qrcode_labels[2];
	void GetModelPaths();
	int run(const cv::Mat& input_bmp_image);
	std::string logger_path;
};