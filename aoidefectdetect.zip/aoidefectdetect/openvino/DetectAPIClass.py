# -*- coding: utf-8 -*-
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/7/26
@Desc   ：detection for openvino
=================================================='''
import os
import math
import cv2
import torch
import numpy as np
from openvino_detect import Detection,nms,softmax,clip_detections
from openvino.inference_engine import IECore




smt_cls = ["ng","ok"]
image_ext = [".jpg", ".jpeg", ".webp", ".bmp", ".png"]
classes_det = ['c', 'r','j','d','x','v','u','l']
classes_det_dict = {'C': 0, 'R': 1, 'J': 2, 'D': 3, 'X': 4, 'V': 5, 'U': 6, 'L': 7}
pcb_classes = {'solder':0, 'welding':1,'excess_solder':2,'tin':3,'skipping':4,'weld':5}
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/8/5
@Desc   ：detect class
=================================================='''
class det_Predictor(object):
    def __init__(self,classes,model_path):
        self.strides = [8, 16, 32, 64]
        self.ad = 0.5
        self.reg_max = 7
        self.classes = classes
        self.confidence_threshold = 0.7
        self.iou_threshold = 0.5
        self.ie = IECore()
        self.model_path = model_path
        self.net = self.ie.read_network(model=self.model_path)
        self.input_blob = next(iter(self.net.input_info))
        self.out_blob = next(iter(self.net.outputs))
        self.net.batch_size=1
        _,_,self.h, self.w = self.net.input_info[self.input_blob].input_data.shape
        self.exec_net = self.ie.load_network(network=self.net, device_name="CPU")
       
    def distance2bbox(self, points, distance, max_shape=None):
        x1 = points[:, 0] - distance[:, 0]
        y1 = points[:, 1] - distance[:, 1]
        x2 = points[:, 0] + distance[:, 2]
        y2 = points[:, 1] + distance[:, 3]
        if max_shape is not None:
            x1 = np.clip(x1, 0, max_shape[1])
            y1 = np.clip(y1, 0, max_shape[0])
            x2 = np.clip(x2, 0, max_shape[1])
            y2 = np.clip(y2, 0, max_shape[0])
        return np.stack([x1, y1, x2, y2], axis=-1)
    def get_single_level_center_point(self,featmap_size, stride):
        h, w = featmap_size
        x_range, y_range = (np.arange(w) + self.ad) * stride, (np.arange(h) + self.ad) * stride
        y, x = np.meshgrid(y_range, x_range, indexing='ij')
        return y.flatten(), x.flatten()

    def get_bboxes(self,reg_preds, input_height, input_width):
        self.strides = [8, 16, 32, 64]
        featmap_sizes = [(math.ceil(input_height / stride), math.ceil(input_width) / stride) for stride in self.strides]
        list_center_priors = []
        for stride, featmap_size in zip(self.strides, featmap_sizes):
            y, x = self.get_single_level_center_point(featmap_size, stride)
            self.strides = np.full_like(x, stride)
            list_center_priors.append(np.stack([x, y, self.strides, self.strides], axis=-1))
        center_priors = np.concatenate(list_center_priors, axis=0)
        dist_project = np.linspace(0, self.reg_max, self.reg_max + 1)
        x = np.dot(softmax(np.reshape(reg_preds, (*reg_preds.shape[:-1], 4, self.reg_max + 1)), -1, True), dist_project)
        dis_preds = x * np.expand_dims(center_priors[:, 2], -1)
        return self.distance2bbox(center_priors[:, :2], dis_preds, (input_height, input_width))

    def rescale_detections(self,detections, meta):
        input_h, input_w, _ = meta['resized_shape']
        orig_h, orig_w, _ = meta['original_shape']
        w = orig_w / input_w
        h = orig_h / input_h

        for detection in detections:
            detection.xmin *= w
            detection.xmax *= w
            detection.ymin *= h
            detection.ymax *= h
        return clip_detections(detections, meta['original_shape'])
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/8/12
@Desc   ：smt classify class
=================================================='''
class cls_Predictor(object):
    def __init__(self,model_path):
        self.ie = IECore()
        self.model_path=model_path
        #model="ctdet_coco_dlav0_512/ctdet_coco_dlav0_512.xml"
        self.net = self.ie.read_network(model=self.model_path)
        self.input_blob = next(iter(self.net.input_info))
        self.out_blob = next(iter(self.net.outputs))
        self.net.batch_size=1
        _, _, self.h, self.w = self.net.input_info[self.input_blob].input_data.shape
        
        self.exec_net = self.ie.load_network(network=self.net, device_name="CPU")
# image process to torch tensor
def imageDeal(cvimg,w,h):
    image = cv2.resize(cvimg, (w, h))
    image = image.transpose((2, 0, 1))[::-1]  # BGR to RGB, to 3x416x416
    image = np.ascontiguousarray(image)
    image = torch.from_numpy(image.astype(np.float32)).div_(255.0)
    
    if torch.cuda.is_available():
        img_normalize = torch.unsqueeze(image, 0).cuda()
    else:img_normalize = torch.unsqueeze(image, 0)
    return img_normalize
# read image with chinese name
def readImg(path):
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    return img
# get smt classify result
def cls_classify(cls_image,cls_predictor):
    cls_image = imageDeal(cls_image,cls_predictor.w,cls_predictor.h)
    out = cls_predictor.exec_net.infer(inputs={cls_predictor.input_blob: cls_image})
    out = torch.tensor(out[cls_predictor.out_blob])
    percentage = torch.nn.functional.softmax(out, dim=1)[0]
    return percentage.numpy().tolist()
    #return ngList
# get  detect result
def det_predict(image_path,det_predictor):
    org_image = readImg(image_path)

    meta = {'original_shape': org_image.shape}
    if org_image.shape[:-1] != (det_predictor.h, det_predictor.w):
        image = cv2.resize(org_image, (det_predictor.w, det_predictor.h))
        meta.update({'resized_shape': image.shape})
    image = image.transpose((2, 0, 1))

    res = det_predictor.exec_net.infer(inputs={det_predictor.input_blob: image})
    output = res[det_predictor.out_blob][0]
    cls_scores = output[:,:len(det_predictor.classes)]
    
    bbox_pred = output[:,len(det_predictor.classes):]
    bboxes = det_predictor.get_bboxes(bbox_pred, det_predictor.h, det_predictor.w)
    dets = []
    for label, score in enumerate(np.transpose(cls_scores)):
        mask = score > det_predictor.confidence_threshold
        filtered_boxes, score = bboxes[mask, :], score[mask]
        if score.size == 0:
            continue
        x_mins, y_mins, x_maxs, y_maxs = filtered_boxes.T
        keep = nms(x_mins, y_mins, x_maxs, y_maxs, score,det_predictor.iou_threshold, include_boundaries=True)
        score = score[keep]
        x_mins, y_mins, x_maxs, y_maxs = x_mins[keep], y_mins[keep], x_maxs[keep], y_maxs[keep]
        labels = np.full_like(score, label, dtype=int)
        dets += [Detection(*det) for det in zip(x_mins, y_mins, x_maxs, y_maxs, score, labels)]
    detections = det_predictor.rescale_detections(dets, meta)
    return detections,org_image
# get classify result and return NG or OK
def cls_predict(detections,org_image,cls_predictor,class_name):
    detectList=[]
    cnt=0
    for detection in detections:
        class_id = int(detection.id)
        xmin, ymin, xmax, ymax = detection.get_coords()
        #score = np.sum(detection.score)+1
        #score = score -1
        if xmin<10 or ymin<10 or org_image.shape[0]-ymax < 10 or org_image.shape[1]-xmax < 10:
            continue
        bbox = [xmin, ymin, xmax, ymax]
        #print(class_id, xmin, ymin, xmax, ymax, score)
        if class_id==classes_det_dict[class_name]:
            cls_image = org_image[ymin:ymax,xmin:xmax]
            if cls_image.shape[0]<cls_image.shape[1]:
                cls_image = cv2.transpose(cls_image)
                cv2.imwrite("images/"+str(cnt)+".jpg",cls_image)
                cnt+=1
            res = cls_classify(cls_image,cls_predictor)
            
            if res[0]>0.5:detectList.append((bbox,res[0]))
        else:
            continue
        
    status = "OK" if len(detectList)==0 else "NG"
    return status,detectList
# get detect result and return NG or OK,bbox,score
def pcb_predict(detections,class_name):
    bboxList = []
    for detection in detections:
        class_id = int(detection.id)
        xmin, ymin, xmax, ymax = detection.get_coords()
        score = detection.score
        #print(class_id, xmin, ymin, xmax, ymax, score)
        
        if class_id==pcb_classes[class_name]:
            bboxList.append(([xmin, ymin, xmax, ymax],score))
    status = "OK" if len(bboxList)==0 else "NG"
    return status,bboxList
# get image list
def get_image_list(path):
    image_names = []
    for maindir, subdir, file_name_list in os.walk(path):
        for filename in file_name_list:
            apath = os.path.join(maindir, filename)
            ext = os.path.splitext(apath)[1]
            if ext in image_ext:
                image_names.append(apath)
    return image_names
    
# if __name__ == "__main__":
#      # 1.加载SMT检测模型
#     det_predictor = det_Predictor()
  
#     # 2.加载SMT分类模型
#     cls_predictor = cls_Predictor()
#     imagePath = r"F:/datasets/SMT_DATASET/20220705/val/images"
#     files = get_image_list(imagePath)
#     startTime = time.perf_counter()
#     for image_name in files:
#         print(image_name)
#         predict(image_name,det_predictor,cls_predictor)
#     print(f'model cost:{time.perf_counter() - startTime:.8f}s')
