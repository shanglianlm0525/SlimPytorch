# -*- coding: utf-8 -*-
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Author ：yangmiao
@Date   ：2022/7/27
@Desc   ：detect flask server
=================================================='''
import re
from flask import request, Flask
from gevent import pywsgi
import json
from DetectAPIClass import det_Predictor,cls_Predictor,det_predict,get_image_list,cls_predict,pcb_predict
import os
image_ext = [".jpg", ".jpeg", ".webp", ".bmp", ".png"]
smt_classes = ['c', 'r','j','d','x','v','u','l']
pcb_classes = ['solder', 'welding','excess_solder','tin','skipping','weld']
r_model_path = "r_cls.onnx"
u_model_path = "u_cls.onnx"
smt_model_path = "smt_detect.xml"
pcb_model_path = "pcb_detect.xml"
smt_predictor = det_Predictor(smt_classes,smt_model_path)
pcb_preditor = det_Predictor(pcb_classes,pcb_model_path)
r_predictor = cls_Predictor(r_model_path)
u_predictor = cls_Predictor(u_model_path)


app = Flask(__name__)
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/8/6
@Desc   ：smt detect flask server
=================================================='''
@app.route("/detect", methods=['POST'])
def get_frame():
    respDict = {}
    imageList = []
    class_name = json.loads(request.data)['class']
    image_path = json.loads(request.data)['image_path']
    if os.path.isdir(image_path):
        imageFiles = get_image_list(image_path)
    else:
        imageFiles = [image_path]
    if class_name == "smt":
        component = json.loads(request.data)['component']
        location = json.loads(request.data)['location']
        defect = json.loads(request.data)['defect']
        if component=="R" and defect == "offset":cls_predictor = r_predictor
        elif component=="U" and defect == "welded":cls_predictor = u_predictor
        else:return "Please input the correct component class and defect class"
        for imageFile in imageFiles:
            detections,org_image = det_predict(imageFile,smt_predictor)
            #print(detections,org_image,cls_predictor,component)
            # if not detections:return "Please input the correct Image file"
            Status = cls_predict(detections,org_image,cls_predictor,component)
            if Status[0] == "NG":imageList.append((imageFile,bboxList))

    elif class_name == "pcb":
        defect = json.loads(request.data)['defect']
        for imageFile in imageFiles:
            detections,org_image = det_predict(imageFile,pcb_preditor)
            Status,bboxList = pcb_predict(detections,defect)
            if Status[0] == "NG":imageList.append((imageFile,bboxList))
    respDict["NG_count"] = len(imageList)
    respDict["imageList"] = imageList
    response=json.dumps(respDict)
    return response
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/8/15
@Desc   ：one imageFile detect flask server
=================================================='''
@app.route("/detect_onefile", methods=['POST'])
def detect_onefile():
    respDict = {}
    class_name = json.loads(request.data)['class']
    image_path = json.loads(request.data)['image_path']
    ext = os.path.splitext(image_path)[1]
    if ext not in image_ext:return "Please input the correct Image file path"
    if class_name == "smt":
        component = json.loads(request.data)['component']
        location = json.loads(request.data)['location']
        defect = json.loads(request.data)['defect']
        if component=="R" and defect == "offset":cls_predictor = r_predictor
        elif component=="U" and defect == "weld":cls_predictor = u_predictor
        else:return "Please input the correct component class and defect class"
        detections,org_image = det_predict(image_path,smt_predictor)
        #print(detections,org_image,cls_predictor,component)
        # if not detections:return "Please enter an image with components"
        Status = cls_predict(detections,org_image,cls_predictor,component)
        if Status[0] == "NG":
            respDict["status"] = "NG"
            respDict["bboxList"] = Status[1]
        else:
            respDict["status"] = "OK"
            respDict["bboxList"] =None


    elif class_name == "pcb":
        defect = json.loads(request.data)['defect']
        detections,org_image = det_predict(image_path,pcb_preditor)
        Status = pcb_predict(detections,defect)
        if Status[0] == "NG":
            respDict["status"] = "NG"
            respDict["bboxList"] = Status[1]
        else:
            respDict["status"] = "OK"
            respDict["bboxList"] =None

    response=json.dumps(respDict)
    return response
            

if __name__ == "__main__":
    app.run("0.0.0.0", port=5005,threaded=True,debug=True)
    # server = pywsgi.WSGIServer(('0.0.0.0', 5005), app)
    # server.serve_forever()