# coding=utf-8

smt_classes = ['c', 'r', 'j', 'd', 'x', 'v', 'u', 'l']
pcb_classes = ['solder', 'welding', 'excess_solder', 'tin', 'skipping', 'weld']
r_model_path = "r_cls.onnx"
u_model_path = "u_cls.onnx"
smt_model_path = "smt_detect.xml"
pcb_model_path = "pcb_detect.xml"


class det_Predictor_Set(object):
    strides = [8, 16, 32, 64]
    ad = 0.5
