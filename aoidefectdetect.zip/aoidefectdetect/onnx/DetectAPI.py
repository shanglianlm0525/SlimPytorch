# -*- coding: utf-8 -*-
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Author ：yangmiao
@Date   ：2022/7/27
@Desc   ：detect flask server
=================================================='''
import re
from flask import request, Flask
from gevent import pywsgi
import json
from common.common import get_image_list
from SMTdetect import SMTdetector,SMTpredict,cls_Predictor
from PCBdetect import PCBdetector,PCBpredict,classesDict
import configparser
import os

image_ext = [".jpg", ".jpeg", ".webp", ".bmp", ".png"]

'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/9/27
@Desc   ：read config file and create model class
=================================================='''
def get_config():
    cls_model ={}
    config = configparser.ConfigParser() # 类实例化
    config.read("config.ini")
    value = config['cls']
    for k, val in value.items():
        key = (k.split(',')[0].upper(),k.split(',')[1])
        cls_model[key] = cls_Predictor(val)
    smt_predictor = SMTdetector(config.get('det','smt_model_path'))
    pcb_preditor = PCBdetector(config.get('det','pcb_model_path'))
    
    return cls_model,smt_predictor,pcb_preditor
# smt_model_path = "models/smt/det/smt_detect.onnx"
# pcb_model_path = "models/pcb/pcb_detect.onnx"
# smt_predictor = SMTdetector(smt_model_path)
# pcb_preditor = PCBdetector(pcb_model_path)
cls_predictor_dict,smt_predictor,pcb_preditor = get_config()


app = Flask(__name__)
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/9/6
@Desc   ：smt detect flask server
=================================================='''
@app.route("/detect", methods=['POST'])
def get_frame():
    respDict = {}
    imageList = []
    class_name = json.loads(request.data)['class']
    image_path = json.loads(request.data)['image_path']
    if os.path.isdir(image_path):
        imageFiles = get_image_list(image_path)
    else:
        imageFiles = [image_path]
    if class_name == "smt":
        component = json.loads(request.data)['component']
        location = json.loads(request.data)['location']
        defect = json.loads(request.data)['defect']
        if (component,defect) in cls_predictor_dict.keys():cls_predictor = cls_predictor_dict[(component,defect)]
        else:return "Please input the correct component class and defect class"
        for imageFile in imageFiles:
            ext = os.path.splitext(imageFile)[1]
            if ext not in image_ext:
                print("Please confirm whether the file is non-image file,The path is %s" % imageFile)
                continue
            detections,org_image = smt_predictor.detect(imageFile)
            #print(detections,org_image,cls_predictor,component)
            # if not detections:return "Please input the correct Image file"
            Status = SMTpredict(detections,org_image,cls_predictor,component)
            if Status[0] == "NG":imageList.append((imageFile,Status[1]))

    elif class_name == "pcb":
        defect = json.loads(request.data)['defect']
        if not defect in classesDict.keys():return "Please input the correct defect class, The current defect is %s"%defect
        for imageFile in imageFiles:
            ext = os.path.splitext(imageFile)[1]
            if ext not in image_ext:
                print("Please confirm whether the file is non-image file,The path is %s" % imageFile)
                continue
            detections = pcb_preditor.detect(imageFile)
            Status= PCBpredict(detections,defect)
            #print(Status)
            if Status[0] == "NG":imageList.append((imageFile,Status[1]))
    
    respDict["NG_count"] = len(imageList)
    respDict["imageList"] = imageList
    response=json.dumps(respDict)
    return response
'''=================================================
@IDE    ：vs code
@Author ：yangmiao
@Date   ：2022/9/14
@Desc   ：one imageFile detect flask server
=================================================='''
@app.route("/detect_onefile", methods=['POST'])
def detect_onefile():
    respDict = {}
    class_name = json.loads(request.data)['class']
    image_path = json.loads(request.data)['image_path']
    ext = os.path.splitext(image_path)[1]
    if ext not in image_ext:return "Please input the correct Image file path"
    if class_name == "smt":
        component = json.loads(request.data)['component']
        location = json.loads(request.data)['location']
        defect = json.loads(request.data)['defect']
        if (component,defect) in cls_predictor_dict.keys():cls_predictor = cls_predictor_dict[(component,defect)]
        else:return "Please input the correct component class and defect class"
        detections,org_image = smt_predictor.detect(image_path)
        Status = SMTpredict(detections,org_image,cls_predictor,component)
        if Status[0] == "NG":
            respDict["status"] = "NG"
            respDict["bboxList"] = Status[1]
        else:
            respDict["status"] = "OK"
            respDict["bboxList"] =None


    elif class_name == "pcb":
        defect = json.loads(request.data)['defect']
        if not defect in classesDict.keys():return "Please input the correct defect class"
        detections = pcb_preditor.detect(image_path)
        Status = PCBpredict(detections,defect)

        if Status[0] == "NG":
            respDict["status"] = "NG"
            respDict["bboxList"] = Status[1]
        else:
            respDict["status"] = "OK"
            respDict["bboxList"] =None

    response=json.dumps(respDict)
    return response
            

if __name__ == "__main__":
    #app.run("0.0.0.0", port=5005,threaded=True,debug=True)
    server = pywsgi.WSGIServer(('0.0.0.0', 5005), app)
    server.serve_forever()