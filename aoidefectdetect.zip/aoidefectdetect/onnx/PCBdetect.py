#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os

import cv2,time
import numpy as np

import onnxruntime
from common.data_augment import preproc as preprocess
from common.utils import  multiclass_nms, demo_postprocess
image_ext = [".jpg", ".jpeg", ".webp", ".bmp", ".png"]
classesDict = {}
classesDict = {'solder':0, 'excess_solder':1,'weld':2,"other":3}
def readImg(path):
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    #img = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    return img
class PCBdetector(object):
    def __init__(self, model_path):
        self.input_shape = (640,640)
        self.with_p6 = False
        self.model_path = model_path
        self.session = onnxruntime.InferenceSession(self.model_path)
    def detect(self,image_path):
        origin_img = readImg(image_path)
        img, ratio = preprocess(origin_img, self.input_shape)
        ort_inputs = {self.session.get_inputs()[0].name: img[None, :, :, :]}
        output = self.session.run(None, ort_inputs)
        predictions = demo_postprocess(output[0], self.input_shape, p6=self.with_p6)[0]

        boxes = predictions[:, :4]
        scores = predictions[:, 4:5] * predictions[:, 5:]

        boxes_xyxy = np.ones_like(boxes)
        boxes_xyxy[:, 0] = boxes[:, 0] - boxes[:, 2]/2.
        boxes_xyxy[:, 1] = boxes[:, 1] - boxes[:, 3]/2.
        boxes_xyxy[:, 2] = boxes[:, 0] + boxes[:, 2]/2.
        boxes_xyxy[:, 3] = boxes[:, 1] + boxes[:, 3]/2.
        boxes_xyxy /= ratio
        dets = multiclass_nms(boxes_xyxy, scores, nms_thr=0.45, score_thr=0.6)
        return dets
def PCBpredict(dets,class_name):
    bboxList = []
    if dets is not None:
        final_boxes, final_scores, final_cls_inds = dets[:, :4], dets[:, 4], dets[:, 5]
        for i in range(len(final_boxes)):
            if final_cls_inds[i] == classesDict[class_name]:
                bbox = final_boxes[i].tolist()
                score = round(float(final_scores[i]),6)
                bbox.append(score)
                
                bboxList.append(bbox)
    status = "OK" if len(bboxList)==0 else "NG"
    return status,bboxList
if __name__ == '__main__':
    model_path = "models/pcb/det.onnx"
    image_path = "2.jpg"
    pcb_detector = PCBdetector(model_path)
    
    
    time1 = time.time()
    dets = pcb_detector.detect(image_path)
    status = PCBpredict(dets, "weld")
    print(status)
    print(time.time()-time1)