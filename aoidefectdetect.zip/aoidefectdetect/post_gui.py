
from sqlite3 import connect
import tkinter as tk
from tkinter import *
from tkinter import filedialog,messagebox,ttk
#from ttk import *
import threading
import time
import sys
import queue
import requests,json


def fmtTime(timeStamp):
    timeArray = time.localtime(timeStamp)
    dateTime = time.strftime("%Y-%m-%d %H:%M:%S", timeArray)
    return dateTime

class re_Text():
     
    def __init__(self, queue):
 
        self.queue = queue
 
    def write(self, content):
 
        self.queue.put(content)
 
class GUI():
 
    def __init__(self, root):
 
        #new 一个Quue用于保存输出内容
        self.msg_queue = queue.Queue()
        self.initGUI(root)
 
    #在show_msg方法里，从Queue取出元素，输出到Text
    def show_msg(self):
 
        while not self.msg_queue.empty():
            content = self.msg_queue.get()
            self.text.insert(INSERT, content)
            self.text.see(END)
 
        #after方法再次调用show_msg
        self.root.after(100, self.show_msg)
 
    def initGUI(self, root):
 
        self.root = root

        self.root.title('AOI复判算法测试Demo')
        self.root.geometry('540x540') 
        self.radioVar = tk.IntVar() 
        # radio1 = tk.Radiobutton(self.root,text="单张图片",variable=self.radioVar,value=0)
        # radio1.grid(row=0,column=1,sticky='w')
        # radio2 = tk.Radiobutton(self.root,text="多张图片",variable=self.radioVar,value=1)
        # radio2.grid(row=0,column=2,sticky='w')
        L0 = tk.Label(self.root, width=10,text=" ",font=("Arial",12))
        L0.grid(row=1,column=0)
        row,column = 3,0
        L1 = tk.Label(self.root, width=10,text="图片路径:",font=("Arial",12))
        L1.grid(row=row+5,column=0)
        L2 = tk.Label(self.root, width=10,text="检测类别:",font=("Arial",12))
        L2.grid(row=row+2,column=0)
        L3 = tk.Label(self.root, width=10,text="器件类别:",font=("Arial",12))
        L3.grid(row=row+2,column=2)
        L4 = tk.Label(self.root, width=10,text="位标:   ",font=("Arial",12))
        L4.grid(row=row+3,column=0)
        L5 = tk.Label(self.root, width=10,text="缺陷类别:",font=("Arial",12))
        L5.grid(row=row+3,column=2)

        sumbit_btn1 = tk.Button(self.root,text="选择图片目录",command = self.choose_floder)
        sumbit_btn1.grid(row=row+5,column=7)
        

        # self.e_class = tk.StringVar() #文本输入框
        # self.e_entry1 = tk.Entry(self.root,width=10,textvariable=self.e_class)
        # self.e_entry1.grid(row=row+2,column=1,sticky='w')

        self.e_location = tk.StringVar() #文本输入框
        self.e_entry2 = tk.Entry(self.root,width=10,textvariable=self.e_location)
        self.e_entry2.grid(row=row+3,column=1,sticky='w')
        
        # self.e_component = tk.StringVar() #文本输入框
        # self.e_entry4 = tk.Entry(self.root,width=10,textvariable=self.e_component)
        # self.e_entry4.grid(row=row+2,column=3,sticky='w')

        # self.e_defect = tk.StringVar() #文本输入框
        # self.e_entry5 = tk.Entry(self.root,width=10,textvariable=self.e_defect)
        # self.e_entry5.grid(row=row+3,column=3,sticky='w')

        self.e_image = tk.StringVar() #文本输入框
        self.e_entry3 = tk.Entry(self.root,width=48,textvariable=self.e_image)
        self.e_entry3.grid(row=row+5,column=1,columnspan=6,sticky='w')
        
       
        self.comboxlist1 = ttk.Combobox(self.root,width=8,text="smt")
        self.comboxlist1["values"]=("smt","pcb")
        self.comboxlist1.current(0)
        self.comboxlist1.grid(row=row+2,column=1,sticky='w')
        self.comboxlist2 = ttk.Combobox(self.root,width=8,text="R")
        self.comboxlist2["values"]=("R","U")
        self.comboxlist2.current(0)
        self.comboxlist2.grid(row=row+2,column=3,sticky='w')
        self.comboxlist3 = ttk.Combobox(self.root,width=8,text="offset")
        self.comboxlist3["values"]=("offset","weld","welding","excess_solder","tin","skipping")
        self.comboxlist3.current(0)
        self.comboxlist3.grid(row=row+3,column=3,sticky='w')

        submitButton = tk.Button(self.root, text="开始检测", command=self.show)
        submitButton.grid(row=row+6,column=2,sticky='e')



        self.text = Text(self.root, width=48,height=20)
        self.text.grid(row=row+7,column=1,columnspan=6,sticky="w")
        self.scrollBar = Scrollbar(self.root,width=10,command=self.text.yview)
        self.scrollBar.grid(row=row+7,column=7,sticky=W+N+S)

        #启动after方法
        self.root.after(100, self.show_msg)
 
        #将stdout映射到re_Text
        sys.stdout = re_Text(self.msg_queue)
 
        root.mainloop()
    def choose_file(self): # 选择文件
        selectFileName = filedialog.askopenfilename(title="请选择图片文件")
        self.e_image.set(selectFileName)
    def choose_floder(self): #
        selectFileName = filedialog.askdirectory(title="请选择图片目录")
        self.e_image.set(selectFileName)

    def pathCheck(self):
        errorList = ''
        if self.e_entry3.get() == '':
            errorList += 'Image path cannot be empty\n'
        if errorList != '':
            messagebox.showerror(title="Errors Found!", message=errorList)
        return True if errorList == '' else False

    def __show(self):
        global lock 
        self.text.delete(0.0,tk.END)
        
        image_path = self.e_entry3.get()
        print("Start detect Image:%s"%image_path)
        class_name = self.comboxlist1.get()
        location = self.e_entry2.get()
        component = self.comboxlist2.get()
        defect = self.comboxlist3.get()
        #print(image_path, location, component,class_name,defect)
        # if model_path is None:
        satus = self.pathCheck()
        if class_name=="smt":
            if satus:
                res = {"class":class_name,"image_path":image_path,"component":component,"location":location,"defect":defect}
            else:print("Error: one or more paths are empty")
        else:res = {"class":class_name,"image_path":image_path,"defect":defect}
        res = json.dumps(res)
        try:
            re = requests.post("http://127.0.0.1:5005/detect",data=res)
        except Exception as err:
            print("ERROR:Server Connect failed! Please open the server and try again later")
        print(re.text.encode().decode("unicode_escape"))
    def show(self):
        T = threading.Thread(target=self.__show, args=())
        T.start()
 
if __name__ == "__main__":

    root = Tk()
    myGUI = GUI(root)
 