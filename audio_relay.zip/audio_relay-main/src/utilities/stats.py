import numpy as np
from scipy import stats
from sklearn import metrics
import torch

def d_prime(auc):
    standard_normal = stats.norm()
    d_prime = standard_normal.ppf(auc) * np.sqrt(2.0)
    return d_prime

def calculate_stats(output, target):
    """Calculate statistics including mAP, AUC, etc.

    Args:
      output: 2d array, (samples_num, classes_num)
      target: 2d array, (samples_num, classes_num)

    Returns:
      stats: list of statistic of each class.
    """

    classes_num = target.shape[-1]
    stats = []
    class_acc = {}
    # Class-wise statistics
    for k in range(classes_num):

        # Average precision
        avg_precision = metrics.average_precision_score(
            target[:, k], output[:, k], average=None)

        # AUC
        auc = metrics.roc_auc_score(target[:, k], output[:, k], average=None)

        # Accuracy
        # this is only used for single-label classification such as esc-50, not for multiple label one such as AudioSet
        acc = metrics.accuracy_score(np.argmax(target, 1), np.argmax(output, 1))  # 按列获取最大值的索引

        # np.where(target[:, k] == 1)： 第k+1列里值为1的元素的位置，返回值是一个tuple，tuple的第一个元素是行，四二个元素是列
        # target[np.where(target[:, k] == 1)]  得到target里对应tuple行和列位置的元素
        # 所以就是返回target里值为1的全部元素组成的array
        class_target = target[np.where(target[:, k] == 1)]
        class_output = output[np.where(target[:, k] == 1)]

        acc_class = metrics.accuracy_score(np.argmax(class_target, 1), np.argmax(class_output, 1))
        # print(f'@@@@@@@{["acc_ng","acc_ok"][k]}:', acc_class)
        class_acc[["ng", "ok"][k]] = acc_class
        # Precisions, recalls
        (precisions, recalls, thresholds) = metrics.precision_recall_curve(
            target[:, k], output[:, k])

        # FPR, TPR
        (fpr, tpr, thresholds) = metrics.roc_curve(target[:, k], output[:, k])

        save_every_steps = 1000     # Sample statistics to reduce size
        dict = {'precisions': precisions[0::save_every_steps],
                'recalls': recalls[0::save_every_steps],
                'AP': avg_precision,
                'fpr': fpr[0::save_every_steps],
                'fnr': 1. - tpr[0::save_every_steps],
                'auc': auc,
                'acc': acc
                }
        stats.append(dict)

    return stats, class_acc

