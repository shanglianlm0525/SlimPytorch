import pyaudio
import numpy as np
import multiprocessing


def LOG_RED(string):
    return "<font color=red>" + string + "</font>" "<font color=black> </font>"


class Recorder:
    def __init__(self, mic_num, mic_ids, relay_index_dict, play_audio_set, play_audio_q, rate=22050, channel=1, format=pyaudio.paInt16,
                 num_frames=1323, log_queue=None):
        self.mic_num = mic_num
        self.mic_ids = mic_ids
        self. relay_index_dict = relay_index_dict
        self.play_audio_set = play_audio_set
        self.play_audio_q = play_audio_q
        self.num_frames = num_frames
        self.rate = rate
        self.channel = channel
        self.format = format
        self.log_queue = log_queue
        self.p1 = pyaudio.PyAudio()  # 实例化对象
        if len(self.mic_ids) < self.mic_num:
            self.log_queue.put(LOG_RED(f'USB mic 数量（不小于{self.mic_num}个）错误,检测到{len(self.mic_ids)}个。请插入USB mic后再按开始按钮。'))
            raise ValueError('ERROR:USB mic error!')
        self.stream1 = self.p1.open(format=self.format,
                          channels=self.channel,
                          rate=self.rate,
                          input=True,
                          frames_per_buffer=self.num_frames,
                          input_device_index=self.mic_ids[0],
                          )  # 打开流，传入响应参数
        self.p2 = pyaudio.PyAudio()
        self.stream2 = self.p2.open(format=self.format,
                          channels=self.channel,
                          rate=self.rate,
                          input=True,
                          frames_per_buffer=self.num_frames,
                          input_device_index=self.mic_ids[1],
                          )
        # relay2
        if self.mic_num == 4:
            self.p3 = pyaudio.PyAudio()
            self.stream3 = self.p3.open(format=self.format,
                              channels=self.channel,
                              rate=self.rate,
                              input=True,
                              frames_per_buffer=self.num_frames,
                              input_device_index=self.mic_ids[2],
                              )
            self.p4 = pyaudio.PyAudio()
            self.stream4 = self.p4.open(format=self.format,
                              channels=self.channel,
                              rate=self.rate,
                              input=True,
                              frames_per_buffer=self.num_frames,
                              input_device_index=self.mic_ids[3],
                              )

    def record(self, second=1.5):
        try:

            if self.mic_num == 2:
                relay_index_dict = {'relay1': 0}
                index_Relay_dict = {0: 'relay1'}
            elif self.mic_num == 4:
                relay_index_dict = {'relay1': 1, 'relay2': 0}
                index_Relay_dict = {1: 'relay1', 0: 'relay2'}
            data_frame_num = int(self.rate * second)
            output = np.zeros([data_frame_num, self.mic_num])  # [33075, 2or4]
            if self.mic_num == 2:
                self.stream1.start_stream()
                self.stream2.start_stream()
                for _ in range(int(self.rate*second / self.num_frames)):
                    # relay1
                    data1 = self.stream1.read(self.num_frames)
                    data2 = self.stream2.read(self.num_frames)
                    data1 = np.frombuffer(data1, dtype=np.int16)[None, :]  # [1,1323]
                    data2 = np.frombuffer(data2, dtype=np.int16)[None, :]
                    d = np.stack([data2[0], data1[0]], axis=-1)
                    # 依次把 one_input的 第num_id个(1323, mic_num)个元素替换为data2和data1堆叠后的array
                    output = np.concatenate([output[self.num_frames:, :], d])
                    if self.play_audio_set == 1:
                        self.play_audio_q.put(d)
                self.stream1.stop_stream()
                self.stream2.stop_stream()

            elif self.mic_num == 4:
                self.stream1.start_stream()
                self.stream2.start_stream()
                self.stream3.start_stream()
                self.stream4.start_stream()
                for _ in range(int(self.rate * second / self.num_frames)):
                    # relay2
                    data1 = self.stream1.read(self.num_frames)
                    data2 = self.stream2.read(self.num_frames)
                    data3 = self.stream3.read(self.num_frames)
                    data4 = self.stream4.read(self.num_frames)
                    data1 = np.frombuffer(data1, dtype=np.int16)[None, :]  # [1,1323]
                    data2 = np.frombuffer(data2, dtype=np.int16)[None, :]
                    data3 = np.frombuffer(data3, dtype=np.int16)[None, :]
                    data4 = np.frombuffer(data4, dtype=np.int16)[None, :]
                    d = np.stack([data4[0], data3[0], data2[0], data1[0]], axis=-1)
                    output = np.concatenate([output[self.num_frames:, :], d])
                    if self.play_audio_set == 1:
                        self.play_audio_q.put(np.split(d, 2, axis=-1)[relay_index_dict['relay1']], block=False)
                    elif self.play_audio_set == 2:
                        self.play_audio_q.put(np.split(d, 2, axis=-1)[relay_index_dict['relay2']], block=False)
                self.stream1.stop_stream()
                self.stream2.stop_stream()
                self.stream3.stop_stream()
                self.stream4.stop_stream()
            return output
        except Exception as e:
            self.p1.close(self.stream1)
            self.p2.close(self.stream2)
            self.p1.terminate()
            self.p2.terminate()
            if self.mic_num == 4:
                self.p3.close(self.stream3)
                self.p4.close(self.stream4)
                self.p3.terminate()
                self.p4.terminate()
            self.keepalive_queue.put('ERROR#Recorder:' + str(e))


class Player:
    def __init__(self, queue: multiprocessing.Queue, log_queue, keepalive_queue, rate=22050, channel=2, format=pyaudio.paInt16, num_frames=1024):
        self.queue = queue
        self.log_queue = log_queue
        self.keepalive_queue = keepalive_queue
        self.num_frames = num_frames
        self.rate = rate
        self.channel = channel
        self.format = format
        super(Player, self).__init__()

    def run(self):
        try:
            p = pyaudio.PyAudio()
            stream = p.open(channels=self.channel,
                            rate=self.rate,
                            output=True,
                            format=self.format,
                            )
            while True:
                ret = self.queue.get()
                stream.write(ret, num_frames=self.num_frames)
            stream.stop_stream()
            stream.close()
            p.terminate()
        except Exception as e:
            self.keepalive_queue.put(f'ERROR#Player: {e}')
