import multiprocessing
from relay_api import resource_path, MyWidget, KeepaliveThread, LoggerThread
from PySide6.QtGui import QIcon
import os
import sys
from PySide6 import QtWidgets

if "__main__" == __name__:

    multiprocessing.freeze_support()
    if not os.path.exists("./save_audio"):
        os.mkdir("./save_audio")
    app = QtWidgets.QApplication([])
    app.setWindowIcon(QIcon(resource_path('icon/icon.ico')))
    widget = MyWidget()
    widget.resize(640, 480)
    widget.show()
    kt = KeepaliveThread(widget)
    kt.start()
    lt = LoggerThread(widget.log, widget.log_queue)
    lt.start()
    sys.exit(app.exec())

