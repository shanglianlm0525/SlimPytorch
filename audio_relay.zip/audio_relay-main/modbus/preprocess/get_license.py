from cryptography.fernet import Fernet

key = Fernet.generate_key()
print(key)  # b'RtqikMWYdz45HAuXx-dguw6lmNXgOyT0XIMV8r0TtvU='
