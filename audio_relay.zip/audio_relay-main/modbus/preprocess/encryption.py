import base64
import io
import torch
from cryptography.fernet import Fernet
import wmi


def get_model_key() -> str:
    c = wmi.WMI()
    for cpu in c.Win32_Processor():
        k = cpu.ProcessorId.strip() + 'chint-relay-code'
        return base64.urlsafe_b64encode(k.encode())


c = wmi.WMI()

# step1: 读取pytorch模型，并转成io.Bytes
model = torch.jit.load("../model_files/model.pth")
b = io.BytesIO()
torch.jit.save(model, b)
b.seek(0)  # 这一句不能漏掉

# step2：io.Bytes格式数据转成bytes格式数据
pth_bytes = b.read()

key = get_model_key()
encrypted_data = Fernet(key).encrypt(pth_bytes)

# step4：保存加密文件
with open('../model_files/model.relay', 'wb') as fw:
    fw.write(encrypted_data)
