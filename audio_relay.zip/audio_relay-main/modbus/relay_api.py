import base64
import io
import multiprocessing
from multiprocessing import Event
import os
import sys
import time
import datetime
import pyaudio
import soundfile
import torchaudio
import torch
import numpy as np
import wmi
from cryptography.fernet import Fernet
from PySide6 import QtCore, QtWidgets, QtGui
from PySide6.QtWidgets import QFileDialog, QRadioButton, QWidget, QComboBox
from recorder import Player, Recorder
from plc import PLC

AUDIO_RATE = 22050
AUDIO_INTERVAL = 1.5
AUDIO_FRAMES_PER_BUFFER = 1323

AI_PLAY_AUDIO_DEFAULT = 0
AI_INFERENCE_INTERVAL_DEFAULT = 300
AI_SAVE_AUDIO_DEFAULT = 0.0
AI_MELBINS = 384
AI_NORM_MEAN = -4.6476
AI_NORM_STD = 4.5699
AI_TARGET_LENGTH = 172
AI_UINT16_MAX = 32768
START = 1
HOST = "127.0.0.1"
PORT = 88888
ADDRESS = 0X000
SLAVE = 1


UI_LOG_SHOW_MAX_LINE_NUM = 1000

relay_index_dict, index_Relay_dict = {}, {}


def condition():
    time.sleep(0.5)
    return True

def ni_chou_sha() -> bytes:
    c = wmi.WMI()
    for cpu in c.Win32_Processor():
        k = cpu.ProcessorId.strip() + 'chint-relay-code'
        return base64.urlsafe_b64encode(bytes(k.encode()))


def chou_ni_za_di(m_p):
    with open(m_p, 'rb') as fr:
        encrypted_data = fr.read()
    decrypted_data = Fernet(ni_chou_sha()).decrypt(encrypted_data)
    b = io.BytesIO(decrypted_data)
    b.seek(0)
    return torch.jit.load(b)


def resource_path(relative_path):
    if getattr(sys, 'frozen', False):  # 是否Bundle Resource
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


def get_usb_mic(logger):
    p = pyaudio.PyAudio()
    mic = []
    info = p.get_host_api_info_by_index(0)
    numdevices = info.get('deviceCount')
    for i in range(0, numdevices):
        device = p.get_device_info_by_host_api_device_index(0, i)
        if device.get('maxInputChannels') > 0 and device.get('name').__contains__('USB'):
            logger.put(f"USB mic id {i}  -  {p.get_device_info_by_host_api_device_index(0, i).get('name')}")
            mic.append(i)
    return mic


def LOG_RED(string):
    return "<font color=red>" + string + "</font>" "<font color=black> </font>"


def LOG_GREEN(string):
    return "<font color=green>" + string + "</font>" "<font color=black> </font>"


class Relay:
    def __init__(self):
        self.melbins = AI_MELBINS
        self.norm_mean = AI_NORM_MEAN
        self.norm_std = AI_NORM_STD
        self.target_length = AI_TARGET_LENGTH

    def _wav2fbank(self, waveform, sr):
        waveform = waveform - waveform.mean()
        fbank0 = torchaudio.compliance.kaldi.fbank(waveform, htk_compat=True, sample_frequency=sr, use_energy=False,
                                                   window_type='hanning', num_mel_bins=self.melbins, dither=0.0,
                                                   channel=0,  ########0
                                                   frame_shift=10)
        fbank1 = torchaudio.compliance.kaldi.fbank(waveform, htk_compat=True, sample_frequency=sr, use_energy=False,
                                                   window_type='hanning', num_mel_bins=self.melbins, dither=0.0,
                                                   channel=1,  #########1
                                                   frame_shift=10)
        n_frames = fbank0.shape[0]
        p = self.target_length - n_frames
        # cut and pad
        if p > 0:
            m = torch.nn.ZeroPad2d((0, 0, 0, p))
            fbank0 = m(fbank0)
            fbank1 = m(fbank1)
        elif p < 0:
            fbank0 = fbank0[0:self.target_length, :]
            fbank1 = fbank1[0:self.target_length, :]
        fbank = torch.stack([fbank0, fbank1])
        return fbank, 0

    def preprocess(self, data, sr):
        fbank, mix_lambda = self._wav2fbank(data, sr)
        fbank = (fbank - self.norm_mean) / self.norm_std
        fbank = fbank[None, :]
        return fbank


class Inference:
    def __init__(self,  mic_num,
                 mic_ids, model_path, keepalive_queue, play_audio_q, rate, interval,
                 # inference_interval,
                 num_frames, log_queue, pause_event, play_audio_set=AI_PLAY_AUDIO_DEFAULT, logger_ng_flag_set=False,
                 logger_ok_flag_set=False,
                 save_audio_set=AI_SAVE_AUDIO_DEFAULT):
        self.mic_num = mic_num
        self.mic_ids = mic_ids
        self.model_path = model_path
        self.keepalive_queue = keepalive_queue
        self.play_audio_q = play_audio_q
        self.rate = rate
        self.interval = interval
        # self.inference_interval = inference_interval
        self.num_frames = num_frames
        self.log_queue = log_queue
        self.pause_event = pause_event
        self.play_audio_set = play_audio_set
        self.logger_ng_flag_set = logger_ng_flag_set
        self.logger_ok_flag_set = logger_ok_flag_set
        self.save_audio_set = save_audio_set



    def run(self):
        r = Relay()
        # plc = PLC(host=HOST, address=ADDRESS, port=PORT, log_queue=self.log_queue, slave=SLAVE)  # TODO 调试modbus
        # plc.connect()
        try:
            try:
                if '.relay' in self.model_path:
                    audio_model = chou_ni_za_di(self.model_path)
                else:
                    audio_model = torch.jit.load(self.model_path)
            except Exception as e:
                self.keepalive_queue.put('ERROR#Inference:模型文件无效'+str(e))
            # start = datetime.datetime.now()
            audio_model.float().eval()  # evaluate 模式
            # end = datetime.datetime.now()
            # print(f"Evaluating costs: {(end-start).total_seconds()} seconds")
            if self.mic_num == 2:
                relay_index_dict = {'relay1': 0}
                index_Relay_dict = {0: 'relay1'}
            elif self.mic_num == 4:
                relay_index_dict = {'relay1': 1, 'relay2': 0}
                index_Relay_dict = {1: 'relay1', 0: 'relay2'}
            save_id = 0
            self.log_queue.put(f"检测程序开始运行...")
            recorder = Recorder(self.mic_num, self.mic_ids, relay_index_dict, self.play_audio_set, self.play_audio_q)
            while True:
                # if plc.read_plc() == START:  # TODO 调试modbus
                if condition():  # debug  要删
                    audio = recorder.record(self.interval)
                    # 如果pause没有被按下
                    if not self.pause_event.is_set():
                        data_org = audio / AI_UINT16_MAX  # int->float,（33075，4） / 32768
                        data = torch.from_numpy(data_org)
                        if self.mic_num == 4:  # double relay mode
                            data_org = np.split(data_org, 2, axis=-1)  # waveform
                        data = torch.transpose(data, 1, 0)  # [33075, 2 or 4] -> [2 or 4,33075]
                        if self.mic_num == 4:
                            data = list(torch.split(data, 2))
                            for i in range(len(data)):
                                data[i] = r.preprocess(data[i], self.rate)  # （1，2，172，384） return: fbank
                            data = torch.cat(data, dim=0)  # (2,2,172,384)
                        else:
                            data = r.preprocess(data, self.rate)  # （1，2，172，384）
                        ret = audio_model(data.float())
                        result = []
                        write_value = 1
                        for i in range(len(ret)):
                            ok_p = ret[i][1].detach().numpy().round(2)
                            if ret[i].argmax() == 0:  # NG， 一个为NG则返回NG给寄存器
                                write_value = 0
                                if self.logger_ng_flag_set:
                                    result.append(LOG_RED(f"{index_Relay_dict[i]} NG:{str(ret[i][0].detach().numpy().round(2))}"))
                            else:
                                if self.logger_ok_flag_set:
                                    result.append(LOG_GREEN(f"{index_Relay_dict[i]} OK:{str(ok_p)}"))
                            if ok_p <= self.save_audio_set:  # 12ms
                                save_id += 1
                                save_name = os.path.join("./save_audio",
                                                         f"{index_Relay_dict[i]}"
                                                         f"_{time.localtime().tm_mon}_{time.localtime().tm_mday}"
                                                         f"_{time.localtime().tm_hour}_{time.localtime().tm_min}"
                                                         f"_{save_id}_{str(ok_p)}.wav")
                                soundfile.write(save_name, data_org[i], AUDIO_RATE)
                        # plc.write_plc(write_value)  # TODO int, 0为抛料，1为流料
                        if self.logger_ok_flag_set or self.logger_ng_flag_set:
                                self.log_queue.put("".join(result), block=False)
        except Exception as e:
            self.keepalive_queue.put('ERROR #Inference:' + str(e))
            # plc.disconnect_plc() # TODO 调试modbus


class RelayProject:
    def __init__(self,  mic_num,
                 model_path, log_queue, result_queue, keepalive_queue, pause_event, logger_ng_flag_set=False,
                 logger_ok_flag_set=False, play_audio_set=AI_PLAY_AUDIO_DEFAULT,
                 # inference_interval_set=AI_INFERENCE_INTERVAL_DEFAULT,
                 save_audio_set=AI_SAVE_AUDIO_DEFAULT):
        self.model_path = model_path
        self.mic_num = mic_num
        self.log_queue = log_queue
        self.result_queue = result_queue
        self.rate = AUDIO_RATE
        self.interval = AUDIO_INTERVAL
        # 22050*1.5/25, 1323指的是1500ms分25份 每份60ms，60ms中占了1323个振幅信息
        # 音频采集frames_per_buffer设置为1323
        self.num_frames = AUDIO_FRAMES_PER_BUFFER
        self.play_audio_set = play_audio_set
        # self.inference_interval = inference_interval_set  # 300ms(必须是60（其实是60ms）的倍数) 推理一次
        self.play_audio_set = play_audio_set
        self.pause_event = pause_event
        self.logger_ng_flag_set = logger_ng_flag_set
        self.logger_ok_flag_set = logger_ok_flag_set
        self.save_audio_set = save_audio_set
        self.keepalive_queue = keepalive_queue
        self.audio = None
        self.play_audio_q = None

    def run(self):
        mic_ids = get_usb_mic(self.log_queue)
        if len(mic_ids) < self.mic_num:
            self.log_queue.put(LOG_RED(f'USB mic 数量（不小于{self.mic_num}个）错误,检测到{len(mic_ids)}个。请插入USB mic后再按开始按钮。'))
            raise ValueError('ERROR:USB mic error!')
        self.play_audio_q = multiprocessing.Queue(maxsize=10)
        play = Player(self.play_audio_q, self.log_queue, self.keepalive_queue, rate=self.rate, channel=2,
                      num_frames=self.num_frames)
        inference = Inference(self.mic_num,
                              mic_ids, self.model_path, self.keepalive_queue, self.play_audio_q,
                              self.rate, self.interval,
                              # self.inference_interval,
                              self.num_frames, self.log_queue, self.pause_event,
                              self.play_audio_set,
                              self.logger_ng_flag_set, self.logger_ok_flag_set, self.save_audio_set,
                              )
        infer1 = multiprocessing.Process(target=inference.run)
        infer1.name = '检测进程'
        infer1.daemon = True
        infer1.start()

        if self.play_audio_set:
            play1 = multiprocessing.Process(target=play.run)
            play1.name = '播音进程'
            play1.daemon = True
            play1.start()
            return True, (play1, infer1)
        else:
            return True, (None, infer1)


class MyWidget(QtWidgets.QWidget):

    def __init__(self):
        super().__init__()
        self.joins = []
        self.model_path_set = None
        self.double_relay_flag_set = False
        self.logger_ng_flag_set = False
        self.logger_ok_flag_set = False
        self.pause_event = Event()
        self.play_audio_set = AI_PLAY_AUDIO_DEFAULT
        # self.inference_interval_set = AI_INFERENCE_INTERVAL_DEFAULT
        self.save_audio_set = AI_SAVE_AUDIO_DEFAULT
        self.log_queue = multiprocessing.Queue(maxsize=10)
        self.keepalive_queue = multiprocessing.Queue(maxsize=10)
        self.result_queue = multiprocessing.Queue(maxsize=10)
        self.setWindowTitle("继电器尾音检测V1.0")
        self.double_relay_button = QRadioButton('双继电器')
        self.double_relay_button.setAutoExclusive(False)
        self.logger_ng_button = QRadioButton('显示NG')
        self.logger_ng_button.setAutoExclusive(False)
        self.logger_ok_button = QRadioButton('显示OK')
        self.logger_ok_button.setAutoExclusive(False)
        self.double_relay_button.setChecked(self.double_relay_flag_set)
        self.logger_ng_button.setChecked(self.logger_ng_flag_set)
        self.logger_ok_button.setChecked(self.logger_ok_flag_set)

        self.play_cb = QComboBox(self)
        self.play_cb_label = QtWidgets.QLabel("播放: ", alignment=QtCore.Qt.AlignJustify)
        self.play_cb.addItems(['不播放 0', '继电器 1', ])

        # self.inference_interval_cb = QComboBox(self)
        # self.inference_interval_cb_label = QtWidgets.QLabel('检测间隔(ms):', alignment=QtCore.Qt.AlignLeft)
        # self.inference_interval_cb.addItems(['1500'])

        self.save_audio_cb = QComboBox(self)
        self.save_audio_cb_label = QtWidgets.QLabel('音频保存:', alignment=QtCore.Qt.AlignJustify)
        self.save_audio_cb.addItems(['不保存(0.0)', 'NG(0.3)', 'NG(0.4)', 'NG(0.5)', 'NG&OK(0.6)',
                                     'NG&OK(0.7)', 'NG&OK(0.8)', 'NG&OK(0.9)', '全保存(1.0)'])

        self.button_pth = QtWidgets.QPushButton("更改模型文件（.relay）")
        self.button_pause = QtWidgets.QPushButton("暂停")
        self.button_pause.hide()  # 在开始之前，暂停键不可见
        self.button_run = QtWidgets.QPushButton("开始")
        self.log = QtWidgets.QTextBrowser(self)
        self.log.document().setMaximumBlockCount(UI_LOG_SHOW_MAX_LINE_NUM)

        self.label = QtWidgets.QLabel('设置:', alignment=QtCore.Qt.AlignLeft)
        self.log.setText(LOG_GREEN("注：模型文件如果不选择将采用默认模型文件\n"))

        self.vboxlayout_global = QtWidgets.QVBoxLayout(self)

        self.gridlayout = QtWidgets.QGridLayout(self)
        self.gridlayout.addWidget(self.label, 1, 1)
        self.gridlayout.addWidget(self.double_relay_button, 2, 1)
        self.gridlayout.addWidget(self.logger_ng_button, 2, 2)
        self.gridlayout.addWidget(self.logger_ok_button, 2, 3)

        self.gridlayout.addWidget(self.play_cb_label, 3, 1)
        self.gridlayout.addWidget(self.play_cb, 4, 1)
        # self.gridlayout.addWidget(self.inference_interval_cb_label, 3, 2)
        # self.gridlayout.addWidget(self.inference_interval_cb, 4, 2)
        self.gridlayout.addWidget(self.save_audio_cb_label, 3, 2)
        self.gridlayout.addWidget(self.save_audio_cb, 4, 2)
        self.vboxlayout = QtWidgets.QVBoxLayout(self)
        self.vboxlayout.addWidget(self.log)
        self.vboxlayout.addWidget(self.button_pth)
        self.vboxlayout.addWidget(self.button_run)
        self.vboxlayout.addWidget(self.button_pause)

        self.q1 = QWidget()
        self.q2 = QWidget()
        self.q1.setLayout(self.gridlayout)
        self.q2.setLayout(self.vboxlayout)
        self.vboxlayout_global.addWidget(self.q1)
        self.vboxlayout_global.addWidget(self.q2)
        self.setLayout(self.vboxlayout_global)

        self.button_pth.clicked.connect(self.model_file_path)
        self.button_run.clicked.connect(self.run)
        self.button_pause.clicked.connect(self.pause)
        self.double_relay_button.toggled.connect(self.double_relay_flag_fun)
        self.logger_ng_button.toggled.connect(self.logger_ng_flag)
        self.logger_ok_button.toggled.connect(self.logger_ok_flag)
        self.play_cb.currentTextChanged.connect(self.play_cb_change_value)
        # self.inference_interval_cb.currentTextChanged.connect(self.inference_interval_cb_chang_value)
        self.save_audio_cb.currentTextChanged.connect(self.save_audio_cb_chang_value)

    def play_cb_change_value(self, v):
        self.play_audio_set = int(v.split(' ')[-1])
        self.log_queue.put(f'{self.play_cb_label.text()}{v}')

    def save_audio_cb_chang_value(self, v):
        self.save_audio_set = float(v.split('(')[-1][:-1])
        self.log_queue.put(f'{self.save_audio_cb_label.text()}{v}, 文件保存在工程目录下的save_audio文件夹里。')

    # def inference_interval_cb_chang_value(self, v):
    #     self.inference_interval_set = int(v)
    #     self.log_queue.put(f'{self.inference_interval_cb_label.text()}{v}')

    def logger_ok_flag(self, checked):
        self.logger_ok_flag_set = checked
        if checked:
            self.log_queue.put(f'{self.logger_ok_button.text()}：已开启')
        else:
            self.log_queue.put(f'{self.logger_ok_button.text()}：已关闭')

    def logger_ng_flag(self, checked):
        self.logger_ng_flag_set = checked
        if checked:
            self.log_queue.put(f'{self.logger_ng_button.text()}：已开启')
        else:
            self.log_queue.put(f'{self.logger_ng_button.text()}：已关闭')

    def double_relay_flag_fun(self, checked):
        self.double_relay_flag_set = checked
        if checked:
            self.double_relay_flag_set = True
            self.log_queue.put(f'{self.double_relay_button.text()}：已开启')
            if -1 == self.play_cb.findText('继电器 2'):
                self.play_cb.addItem('继电器 2')

        else:
            self.double_relay_flag_set = False
            self.log_queue.put(f'{self.double_relay_button.text()}：已关闭')
            if -1 != self.play_cb.findText('继电器 2'):
                self.play_cb.removeItem(self.play_cb.findText('继电器 2'))
        # self.play_cb.hide()   # 播放功能对客户不开放，隐藏播放下拉框

    def model_file_path(self):
        self.model_path_set, _ = QFileDialog.getOpenFileName(self, "choose file", r"./")
        self.log_queue.put(f'新模型文件夹路径:{self.model_path_set}')

    def run(self):
        if self.button_run.text() == '开始':
            self.button_pth.hide()
            self.q1.hide()
            self.button_run.setText('结束')
            self.button_pause.show()
            self.button_pause.setText("暂停")
            # 将暂停事件的状态改为False
            if self.pause_event.is_set():
                self.pause_event.clear()
            if not self.model_path_set:
                if not os.path.exists(resource_path(os.path.join('model_files', 'model.relay'))):
                    self.button_pth.show()
                    self.q1.show()
                    self.button_run.setText('开始')
                    self.log_queue.put(LOG_RED('程序运行错误：本地模型文件不存在.'))
                    self.log_queue.put(LOG_RED('检测程序启动失败!'))
                    return False
                else:
                    self.model_path_set = resource_path(os.path.join('model_files', 'model.relay'))
            self.log_queue.put('检测程序启动中...')
            mic_num = 4 if self.double_relay_flag_set else 2
            ret, self.joins = RelayProject(mic_num, self.model_path_set,
                                           self.log_queue, self.result_queue,
                                           logger_ng_flag_set=self.logger_ng_flag_set,
                                           logger_ok_flag_set=self.logger_ok_flag_set,
                                           play_audio_set=self.play_audio_set,
                                           # inference_interval_set=self.inference_interval_set,
                                           save_audio_set=self.save_audio_set,
                                           keepalive_queue=self.keepalive_queue,
                                           pause_event=self.pause_event
                                           ).run()
            if not ret:
                self.button_pth.show()
                self.q1.show()
                self.button_run.setText('开始')
            else:
                self.log_queue.put('检测程序启动完成!')

        else:
            self.button_pth.show()
            self.button_run.setText("暂停")
            self.button_pause.hide()
            self.q1.show()
            self.button_run.setText('开始')
            for one in self.joins:
                if one:
                    self.log_queue.put(f"{one.name}(PID:{one.pid},PPID:{os.getpid()}, PPPID:{os.getppid()})已退出")
                    one.kill()
            # TODO 断开和plc寄存器的链接

    def pause(self):
        if self.button_pause.text() == '暂停':
            self.button_pause.setText("恢复")
            if not self.pause_event.is_set():
                self.pause_event.set()  # 按下暂停，pause——event()的值变为True
        else:
            self.button_pause.setText('暂停')
            if self.pause_event.is_set():
                self.pause_event.clear()


class LoggerThread(QtCore.QThread):
    def __init__(self, logger, log_queue):
        super(LoggerThread, self).__init__()
        self.logger = logger
        self.log_queue = log_queue

    def __del__(self):
        self.wait()

    def run(self):
        while True:
            if self.log_queue:
                ret = self.log_queue.get()
                self.logger.append(ret)
                self.logger.moveCursor(QtGui.QTextCursor.End)
                QtWidgets.QApplication.processEvents()

            else:
                time.sleep(1)


class KeepaliveThread(QtCore.QThread):
    def __init__(self, widget):
        super(KeepaliveThread, self).__init__()
        self.widget = widget
        self.log_queue = widget.log_queue
        self.keepalive_queue = widget.keepalive_queue

    def __del__(self):
        self.wait()

    def run(self):
        while True:
            if self.keepalive_queue:
                ret = self.keepalive_queue.get()
                type_flag, info = ret.split('#')
                if type_flag == 'ERROR':
                    self.log_queue.put(LOG_RED(f"{ret}"))
                    for one in self.widget.joins:
                        self.widget.button_pth.show()
                        self.widget.q1.show()
                        self.widget.button_pause.hide()
                        self.widget.button_run.setText('开始')
                        if one:
                            self.log_queue.put(f"{one.name}(PID:{one.pid},PPID:{os.getpid()}, PPPID:{os.getppid()})已退出")
                            one.kill()
            else:
                time.sleep(1)
