from distutils.core import setup
from Cython.Build import cythonize

setup(
    name='relay app',
    ext_modules=cythonize(module_list=["relay_api.py", "record_and_play.py"]),
)