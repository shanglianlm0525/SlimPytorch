"""
This is to connect H3U PLC and read and write to its register, bu applying modbus tcp protocol
modbus master 为client，连接远程的slave来请求采集到的数据。

modbus slave 为 server ，监听502端口，一般slave为plc，plc为嵌入式设备从modbus网络上采集数据。master发送modbus协议数据请求salve获取数据。


1.连接到远程的slave(即modbus server的502端口服务器)

master = modbus_tcp.TcpMaster("192.168.2.20",502)

master.set_timeout(5.0)


2.进行调用modbus_tk库的接口，向slave请求采集的数据

 类TcpMaster下有如下接口：

set_timeout(秒)

_send(modbus请求) modbus请求，即：需要自己封装modbus协议头和请求命令

_recv() 返回modbus协议数据

open()

close()

execute(slave,功能代码,开始地址,quantity_of_x=0,output_value=0,data_format="",指定长度=-1)//execute为线程安全函数

使用例子：

import modbus_tk.defines as de

master.execute(slave_id=1,de.READ_HOLDING_REGISTERS,100,3)

slave_id:1

 slave_id : identifier of the slave. from 1 to 247.  0为广播所有的slave
功能代码:de.READ_HOLDING_REGISTE  定义见：defines.py

开始地址为: 100

quantity_of_x = 3 （寄存器或者线圈的数量）

output_value: (一个整数或者可迭代的值) 如：

output_value = 1或 54 或 output_value=[1,1,0,1,1,0,1,1] 或者 output_value = xrange(12)

返回的一个元祖类型的数据,返回的元祖取决于查询的功能码，参考详细的modbus协议说明书来构造data_format


modbus 功能代码： defines.py

#modbus 异常代码

ILLEGAL_FUNCTION = 1  功能代码不合法
ILLEGAL_DATA_ADDRESS = 2  数据地址不合法
ILLEGAL_DATA_VALUE = 3  数据值不合法
SLAVE_DEVICE_FAILURE = 4 slave设备失败
COMMAND_ACKNOWLEDGE = 5  命令已收到
SLAVE_DEVICE_BUSY = 6    slave设备忙
MEMORY_PARITY_ERROR = 8 内存奇偶误差

#supported modbus 功能代码
READ_COILS = 1 读线圈
READ_DISCRETE_INPUTS = 2 读离散输入
READ_HOLDING_REGISTERS = 3  【读乘法寄存器】
READ_INPUT_REGISTERS = 4  读输入寄存器
WRITE_SINGLE_COIL = 5  写单一线圈
WRITE_SINGLE_REGISTER = 6  写单一寄存器
WRITE_MULTIPLE_COILS = 15 写多个线圈 【强制多点线圈】
WRITE_MULTIPLE_REGISTERS = 16  写多寄存器 【写乘法寄存器】

#supported block types 支持的块类型
COILS = 1   线圈
DISCRETE_INPUTS = 2  离散输入（数字量输入）
HOLDING_REGISTERS = 3  乘法寄存器
ANALOG_INPUTS = 4 模拟量输入
"""
import time
import multiprocessing
import modbus_tk
import modbus_tk.defines as cst
import modbus_tk.modbus_tcp as modbus_tcp

OK = 1
count = 5
interval = 0.01


class PLC:
    def __init__(self, host, address,  hearbeat_address, port, log_queue, slave=1):
        self.host = host
        self.address = address
        self.slave = slave
        self.hearbeat_address = hearbeat_address
        self.port = port
        self.log_queue = log_queue

    def connect(self):
        self.master = modbus_tcp.TcpMaster(self.host, self.port)
        self.master.set_timeout(5.0)
        self.master.set_verbose(True)
        self.master.open()

    def read_plc(self):
        #  和生产线进行modbus通讯,读取心跳地址，相当于测试连接状态，然后读取要写的寄存器地址
        for i in range(count):
            try:
                return list(self.master.execute(slave=self.slave, function_code=cst.READ_HOLDING_REGISTERS,
                                   starting_address=self.address, quantity_of_x=1))[0]
            except Exception as e:
                try:
                    self.log_queue.put('ERROR#PLC_read:' + str(e))
                    time.sleep(interval)
                    self.connect()
                except Exception as e:
                    self.log_queue.put('ERROR#PLC_read:' + str(e))


    def write_plc(self, value):
        # 把结果写回寄存器
        for i in range(count):
            try:
                hearbeat = self.master.execute(slave=self.slave, function=cst.READ_HOLDING_REGISTERS,
                                               starting_address=self.hearbeat_address)
                if hearbeat[0] == OK:  # TODO 待商定要匹配的值是多少
                    return list(self.master.execute(slave=1, function_code=cst.WRITE_SINGLE_REGISTER,
                                       starting_address=self.address, output_Value=value))[0]
            except Exception as e:
                try:
                    self.log_queue.put('ERROR#PLC_read:' + str(e))
                    time.sleep(interval)
                    self.connect()
                except Exception as e:
                    self.log_queue.put('ERROR#PLC_write:' + str(e))


    def disconnect_plc(self):
        # 断开连接
        self.master.close()
