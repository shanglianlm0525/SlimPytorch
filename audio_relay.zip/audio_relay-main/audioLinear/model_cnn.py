import torch
from torch import nn


class Bottleneck(nn.Module):
    def __init__(self, input_c, output_c, stride, kernel=(1, 32)):
        super(Bottleneck, self).__init__()
        self.stride = stride
        self.kernel_ = kernel
        self.conv1 = nn.Sequential(
            self.depthwise_conv(input_c, input_c, self.kernel_, 1),
            nn.BatchNorm2d(input_c),
            nn.Conv2d(input_c, input_c // 2, 1, 1, bias=False),
            nn.BatchNorm2d(input_c // 2),
            nn.LeakyReLU(),
        )
        self.conv2 = nn.Sequential(
            self.depthwise_conv(input_c // 2, input_c // 2, self.kernel_, 1),
            nn.BatchNorm2d(input_c // 2),
            nn.Conv2d(input_c // 2, input_c // 2, 1, 1, bias=False),
            nn.BatchNorm2d(input_c // 2),
            nn.LeakyReLU(),
        )
        self.conv3 = nn.Sequential(
            self.depthwise_conv(input_c // 2, input_c // 2, self.kernel_, stride),
            nn.BatchNorm2d(input_c // 2),
            nn.Conv2d(input_c // 2, output_c // 2, 1, 1, bias=False),
            nn.BatchNorm2d(output_c // 2),
            nn.LeakyReLU(),
        )
        self.downsample = nn.Sequential(
            self.depthwise_conv(input_c, input_c, self.kernel_, stride),
            nn.BatchNorm2d(input_c),
            nn.Conv2d(input_c, output_c // 2, 1, 1, bias=False),
            nn.BatchNorm2d(output_c // 2),
            nn.LeakyReLU(),
        )
        self.padding = nn.ZeroPad2d(padding=(self.kernel_[1] // 2, self.kernel_[1] // 2, 0, 0))

    @staticmethod
    def depthwise_conv(
            i: int, o: int, kernel_size: int, stride: int = 1, padding: int = 0, bias: bool = False
    ) -> nn.Conv2d:
        return nn.Conv2d(i, o, kernel_size, stride, padding, bias=bias, groups=i)

    def forward(self, x):
        x = self.padding(x)
        net = self.conv1(x)
        net = self.padding(net)
        net = self.conv2(net)
        net = self.padding(net)
        net = self.conv3(net)

        ds = self.downsample(x)
        net = torch.cat([net, ds], dim=1)
        return net


class AudioLinear(nn.Module):
    def __init__(self, input_size=33075):
        super(AudioLinear, self).__init__()
        kernel_ = (1, 3)
        stride_ = 2
        self.scale = 1
        self.conv1 = nn.Sequential(
            nn.Conv2d(2, 16 // self.scale, kernel_, stride_, bias=False),
            nn.BatchNorm2d(16 // self.scale),
            nn.LeakyReLU(),
        )

        # self.conv2 = nn.Sequential( # 0.98298
        #     Bottleneck(16 // self.scale, 32 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(32 // self.scale, 32 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(32 // self.scale, 32 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(32 // self.scale, 32 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(32 // self.scale, 48 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(48 // self.scale, 48 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(48 // self.scale, 48 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(48 // self.scale, 48 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(48 // self.scale, 64 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(64 // self.scale, 64 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(64 // self.scale, 64 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(64 // self.scale, 64 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(64 // self.scale, 96 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(96 // self.scale, 96 // self.scale, stride_, kernel=kernel_),
        #     Bottleneck(96 // self.scale, 96 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(96 // self.scale, 96 // self.scale, 1, kernel=kernel_),
        #     Bottleneck(96 // self.scale, 128 // self.scale, stride_, kernel=kernel_),
        # )

        self.conv2 = nn.Sequential( # 0.98525      acc 0.9835507657402155    epoch: 145
            Bottleneck(16 // self.scale, 32 // self.scale, stride_, kernel=kernel_),
            Bottleneck(32 // self.scale, 32 // self.scale, stride_, kernel=kernel_),
            Bottleneck(32 // self.scale, 32 // self.scale, 1, kernel=kernel_),
            Bottleneck(32 // self.scale, 32 // self.scale, 1, kernel=kernel_),
            Bottleneck(32 // self.scale, 48 // self.scale, stride_, kernel=kernel_),
            Bottleneck(48 // self.scale, 48 // self.scale, stride_, kernel=kernel_),
            Bottleneck(48 // self.scale, 48 // self.scale, 1, kernel=kernel_),
            Bottleneck(48 // self.scale, 48 // self.scale, 1, kernel=kernel_),
            Bottleneck(48 // self.scale, 64 // self.scale, stride_, kernel=kernel_),
            Bottleneck(64 // self.scale, 64 // self.scale, stride_, kernel=kernel_),
            Bottleneck(64 // self.scale, 64 // self.scale, 1, kernel=kernel_),
            Bottleneck(64 // self.scale, 64 // self.scale, 1, kernel=kernel_),
            Bottleneck(64 // self.scale, 96 // self.scale, stride_, kernel=kernel_),
            Bottleneck(96 // self.scale, 96 // self.scale, stride_, kernel=kernel_),
            Bottleneck(96 // self.scale, 96 // self.scale, 1, kernel=kernel_),
            Bottleneck(96 // self.scale, 96 // self.scale, 1, kernel=kernel_),
            Bottleneck(96 // self.scale, 96 // self.scale, 1, kernel=kernel_),
            Bottleneck(96 // self.scale, 128 // self.scale, stride_, kernel=kernel_),
        )

        self.avgpool = nn.AvgPool2d((1, 3))
        self.output = nn.Linear(1408 // self.scale, 2)
        self.act = nn.Sigmoid()

    def forward(self, x):
        net = self.conv1(x)
        net = self.conv2(net)
        net = self.avgpool(net)
        net = torch.flatten(net, 1)
        net = self.act(self.output(net))
        return net


if "__main__" == __name__:
    model = AudioLinear()
    trainables = [p for p in model.parameters() if p.requires_grad]
    print('Total parameter number is : {:.3f} million'.format(sum(p.numel() for p in model.parameters()) / 1e6))
    print('Total trainable parameter number is : {:.3f} million'.format(sum(p.numel() for p in trainables) / 1e6))
    data = torch.ones((1, 2, 1, 33075))
    ret = model(data)
