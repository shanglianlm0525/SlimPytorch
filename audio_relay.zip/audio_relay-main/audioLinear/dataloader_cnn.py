import csv
import json
import torchaudio
import numpy as np
import torch
import torch.nn.functional
from torch.utils.data import Dataset
from generate_log import logger


def make_index_dict(label_csv):
    index_lookup = {}
    with open(label_csv, 'r') as f:
        csv_reader = csv.DictReader(f)
        line_count = 0
        for row in csv_reader:
            index_lookup[row['mid']] = row['index']
            line_count += 1
    return index_lookup


class AudiosetDataset(Dataset):
    def __init__(self, dataset_json_file, label_csv, training=False):
        """
        Dataset that manages audio recordings
        :param audio_conf: Dictionary containing the audio loading and preprocessing settings
        :param dataset_json_file
        """
        self.training = training
        self.datapath = dataset_json_file
        with open(dataset_json_file, 'r') as fp:
            data_json = json.load(fp)

        self.data = data_json['data']
        if self.training:
            logger.info(f"########training dataset: {len(self.data)}")
        else:
            logger.info(f"########val dataset: {len(self.data)}")

        self.index_dict = make_index_dict(label_csv)
        self.label_num = len(self.index_dict)
        logger.info('number of classes is {:d}'.format(self.label_num))

    def __getitem__(self, index):
        """
        returns: image, audio, nframes
        where image is a FloatTensor of size (3, H, W)
        audio is a FloatTensor of size (N_freq, N_frames) for spectrogram, or (N_frames) for waveform
        nframes is an integer
        """
        datum = self.data[index]
        label_indices = torch.zeros(self.label_num)
        waveform, sr = torchaudio.load(datum['wav'])
        for label_str in datum['labels'].split(','):
            label_indices[int(self.index_dict[label_str])] = 1.0

        if self.training:
            if torch.rand(1)[0] < 0.3:
                _factor = np.random.uniform(0.8, 1.2)
                waveform *= _factor
            if torch.rand(1)[0] < 0.3:
                if torch.rand(1)[0] < 0.5:
                    _factor = np.random.uniform(0.65, 1.35)
                    waveform[0] *= _factor
                else:
                    _factor = np.random.uniform(0.65, 1.35)
                    waveform[1] *= _factor

            if np.random.uniform() < 0.5:
                waveform = torch.stack([waveform[0], waveform[1]])
            else:
                waveform = torch.stack([waveform[1], waveform[0]])

        return waveform[:, None, :], label_indices

    def __len__(self):
        return len(self.data)
