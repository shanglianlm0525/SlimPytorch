import datetime
import os
import random

import numpy as np
from model_cnn import AudioLinear
from torch import nn
import torch
from sklearn import metrics
from dataloader_cnn import AudiosetDataset

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
seed = 996
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)  # if you are using multi-GPU.
np.random.seed(seed)  # Numpy module.
random.seed(seed)  # Python random module.
torch.manual_seed(seed)
torch.backends.cudnn.benchmark = False
# torch.backends.cudnn.benchmark = True  # 输入大小是固定的
torch.backends.cudnn.deterministic = True

if "__main__" == __name__:
    model = AudioLinear(input_size=33075)
    model = model.cuda()
    loss_fn = nn.BCELoss()

    trainables = [p for p in model.parameters() if p.requires_grad]
    print('Total parameter number is : {:.3f} million'.format(sum(p.numel() for p in model.parameters()) / 1e6))
    print('Total trainable parameter number is : {:.3f} million'.format(sum(p.numel() for p in trainables) / 1e6))

    optimizer = torch.optim.AdamW(trainables, 0.001, weight_decay=5e-7, betas=(0.95, 0.999))
    train_loader = torch.utils.data.DataLoader(
        AudiosetDataset('../wz_relay_dual/wz_relay_train.json', label_csv='./wz_relay.csv', training=True),
        batch_size=16, num_workers=2, pin_memory=False, shuffle=True)
    val_loader = torch.utils.data.DataLoader(
        AudiosetDataset('../wz_relay_dual/wz_relay_val.json', label_csv='./wz_relay.csv', training=False),
        batch_size=16, num_workers=2, pin_memory=False, shuffle=False)
    # state_dictBA = torch.load("./save_models/audio_model_20.pth", map_location='cpu')
    # model.load_state_dict(state_dictBA)
    val_best_acc = 0
    val_best_epoch = 0
    for one_epoch in range(150):
        print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), end=' - ')
        loss_epoch = 0
        model.train()
        for data, label in train_loader:
            optimizer.zero_grad()
            data = data.cuda()
            label = label.cuda()
            pre = model(data)

            epsilon = 1e-7
            pre = torch.clamp(pre, epsilon, 1. - epsilon)

            one_loss = loss_fn(pre, label)
            loss_epoch = (loss_epoch + one_loss) / 2

            one_loss.backward()
            optimizer.step()
        if one_epoch >= 5 and one_epoch % 5 == 0:
            A_predictions = []
            A_targets = []
            class_acc = {}
            model.eval()
            with torch.no_grad():
                for data, label in val_loader:
                    data = data.cuda()
                    label = label
                    pre = model(data)
                    predictions = pre.to('cpu').detach()
                    A_predictions.append(predictions)
                    A_targets.append(label)
                predictions = torch.cat(A_predictions)
                target = torch.cat(A_targets)
                classes_num = target.shape[-1]
                for k in range(classes_num):
                    class_target = target[np.where(target[:, k] == 1)]
                    class_output = predictions[np.where(target[:, k] == 1)]
                    acc_class = metrics.accuracy_score(np.argmax(class_target, 1), np.argmax(class_output, 1))
                    class_acc[["ng", "ok"][k]] = acc_class
                acc = metrics.accuracy_score(np.argmax(target, 1), np.argmax(predictions, 1))
                if acc > val_best_acc:
                    val_best_acc = acc
                    val_best_epoch = one_epoch
            print("VAL:", class_acc, '   acc:', acc, end='')
            print("@@@@@@@@@@@@@@@@@@@:acc", val_best_acc, '   epoch:', val_best_epoch)
        if one_epoch >= 5 and one_epoch % 10 == 0:
            A_predictions = []
            A_targets = []
            class_acc = {}
            with torch.no_grad():
                for data, label in train_loader:
                    data = data.cuda()
                    label = label
                    pre = model(data)
                    predictions = pre.to('cpu').detach()
                    A_predictions.append(predictions)
                    A_targets.append(label)
                predictions = torch.cat(A_predictions)
                target = torch.cat(A_targets)
                classes_num = target.shape[-1]
                for k in range(classes_num):
                    acc = metrics.accuracy_score(np.argmax(target, 1), np.argmax(predictions, 1))
                    class_target = target[np.where(target[:, k] == 1)]
                    class_output = predictions[np.where(target[:, k] == 1)]
                    acc_class = metrics.accuracy_score(np.argmax(class_target, 1), np.argmax(class_output, 1))
                    class_acc[["ng", "ok"][k]] = acc_class
            print("TRAIN:", class_acc)

        print(f"loss_epoch({one_epoch}):", loss_epoch)
        if one_epoch != 0 and one_epoch % 5 == 0:
            torch.save(model.state_dict(), f"./save_models/audio_model_{one_epoch}.pth")
            # torch.save(model.state_dict(), f"./save_models/audio_model_{one_epoch}_{str(loss_epoch.cpu().detach().numpy().round(5))}.pth")
